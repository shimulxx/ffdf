#include<stdio.h>
#define SIZEN 1003

int Grid[SIZEN][SIZEN];
int Visited[SIZEN][SIZEN];
int N, M, L;
int Ans;
int isUp(int n)
{
	switch (n) {
	case 1:
	case 2:
	case 4:
	case 7:
		return 1;
	}
	return 0;
}
int isDown(int n)
{
	switch (n) {
	case 1:
	case 2:
	case 5:
	case 6:
		return 1;
	}
	return 0;
}
int isLeft(int n)
{
	switch (n) {
	case 1:
	case 3:
	case 6:
	case 7:
		return 1;
	}
	return 0;
}
int isRight(int n)
{
	switch (n) {
	case 1:
	case 3:
	case 4:
	case 5:
		return 1;
	}
	return 0;
}

typedef struct queueStruct {
	int x, y, len;
}Queue;
Queue Q[SIZEN*SIZEN];
int front, rear;
void initQueue()
{
	front = rear = 0;
}
int isEmpty()
{
	return (front == rear);
}
void push(int x, int y, int len)
{
	Q[rear].x = x;
	Q[rear].y = y;
	Q[rear].len = len;
	rear++;
}
Queue pop()
{
	return Q[front++];
}
int main()
{
	int T;
	int X, Y;
	int i, j;
	Queue q;
	freopen("input.txt", "r", stdin);
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d %d %d %d", &N, &M, &X, &Y, &L);
		for (i = 0; i < N; i++) for (j = 0; j < M; j++) {
			scanf("%d", &Grid[i][j]);
			if (Grid[i][j])
				Visited[i][j] = 0;
			else
				Visited[i][j] = 1;
		}
		Ans = 0;
		initQueue();
		if (Grid[X][Y]) {
			push(X, Y, 1);
			Visited[X][Y] = 1;
			Ans++;
		}
		while (!isEmpty()) {
			q = pop();
			if (q.len < L) {
				if (q.x - 1 >= 0 && 0 == Visited[q.x - 1][q.y]
					&& isUp(Grid[q.x][q.y]) && isDown(Grid[q.x - 1][q.y])) {
					push(q.x - 1, q.y, q.len + 1);
					Visited[q.x - 1][q.y] = 1;
					Ans++;
				}
				if (q.y - 1 >= 0 && 0 == Visited[q.x][q.y - 1]
					&& isLeft(Grid[q.x][q.y]) && isRight(Grid[q.x][q.y - 1])) {
					push(q.x, q.y - 1, q.len + 1);
					Visited[q.x][q.y - 1] = 1;
					Ans++;
				}
				if (q.y + 1 < M && 0 == Visited[q.x][q.y + 1]
					&& isRight(Grid[q.x][q.y]) && isLeft(Grid[q.x][q.y + 1])) {
					push(q.x, q.y + 1, q.len + 1);
					Visited[q.x][q.y + 1] = 1;
					Ans++;
				}
				if (q.x + 1 < N && 0 == Visited[q.x + 1][q.y]
					&& isDown(Grid[q.x][q.y]) && isUp(Grid[q.x + 1][q.y])) {
					push(q.x + 1, q.y, q.len + 1);
					Visited[q.x + 1][q.y] = 1;
					Ans++;
				}
			}
		} // end while

		printf("%d\n", Ans);
	}
	return 0;
}