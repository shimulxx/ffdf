#include<stdio.h>
#define SIZEN 1003

int Grid[SIZEN][SIZEN];
int Visited[SIZEN][SIZEN];
int N, M, L;
int Ans;
int isUp(int n)
{
	switch (n) {
	case 1:
	case 2:
	case 4:
	case 7:
		return 1;
	}
	return 0;
}
int isDown(int n)
{
	switch (n) {
	case 1:
	case 2:
	case 5:
	case 6:
		return 1;
	}
	return 0;
}
int isLeft(int n)
{
	switch (n) {
	case 1:
	case 3:
	case 6:
	case 7:
		return 1;
	}
	return 0;
}
int isRight(int n)
{
	switch (n) {
	case 1:
	case 3:
	case 4:
	case 5:
		return 1;
	}
	return 0;
}
void go(int x, int y, int len)
{
	if (len > L)
		return;
	if (Visited[x][y])
		return;
	Ans++;
	Visited[x][y] = 1;
	if (x - 1 >= 0 && isUp(Grid[x][y]) && isDown(Grid[x - 1][y]))
		go(x - 1, y, len + 1);
	if (y - 1 >= 0 && isLeft(Grid[x][y]) && isRight(Grid[x][y - 1]))
		go(x, y - 1, len + 1);
	if (y + 1 < M && isRight(Grid[x][y]) && isLeft(Grid[x][y + 1]))
		go(x, y + 1, len + 1);
	if (x + 1 < N && isDown(Grid[x][y]) && isUp(Grid[x + 1][y]))
		go(x + 1, y, len + 1);
}
int main()
{
	int T;
	int X, Y;
	int i, j;
	freopen("input.txt", "r", stdin);
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d %d %d %d", &N, &M, &X, &Y, &L);
		for (i = 0; i < N; i++) for (j = 0; j < M; j++) {
			scanf("%d", &Grid[i][j]);
			if (Grid[i][j])
				Visited[i][j] = 0;
			else
				Visited[i][j] = 1;
		}
		Ans = 0;
		go(X, Y, 1);
		printf("%d\n", Ans);
	}
	return 0;
}