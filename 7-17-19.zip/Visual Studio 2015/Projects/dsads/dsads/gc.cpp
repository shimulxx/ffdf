#include<stdio.h>
char grid[200][200];
char data;
char rdata;
int done;
int grow;
void input();
void gridInt();
void solveWork();
void display();
void find(int i, int j);
void fill(int i, int j);
int main()
{
	freopen("p1.txt", "r", stdin);
	freopen("pout.txt", "w", stdout);
	gridInt();
	input();
	solveWork();
	display();
}
void input()
{
	grow = 0;
	while (gets(grid[grow]) && grid[grow][0] != EOF)
	{
		++grow;
	}
}
void gridInt()
{
	int i, j;
	for (i = 0; i < 200; i++)
	{
		for (j = 0; j < 200; j++)
		{
			grid[i][j] = '\0';
		}
	}
}
void solveWork()
{
	int i, j, k, l;

	for (i = 0; i < grow; i++)
	{
		for (j = 0; grid[i][j] != '\0'; j++)
		{
			if (grid[i][j] == ' ')
			{
				data = grid[i][j - 1];
				done = 0;
				find(i, j);
				fill(i, j);
			}
		}
	}
}
void find(int i, int j)
{
	grid[i][j] = '_';
	//i-1 j
	if (i - 1 >= 0 && done == 0)
	{
		if (' ' == grid[i - 1][j])
		{
			find(i - 1, j);
		}
		if (grid[i - 1][j] != ' ' && grid[i - 1][j] != '_' && grid[i - 1][j] != data)
		{
			done = 1;
			rdata = grid[i - 1][j];
		}
	}
	//i+1 j
	if (i + 1 < 200 && done == 0)
	{
		if (' ' == grid[i + 1][j])
		{
			find(i + 1, j);
		}
		if (grid[i + 1][j] != ' ' && grid[i + 1][j] != data && grid[i + 1][j] != '_')
		{
			done = 1;
			rdata = grid[i + 1][j];
		}
	}
	//i j-1
	if (j - 1 >= 0 && done == 0)
	{
		if (' ' == grid[i][j - 1])
		{
			find(i, j - 1);
		}
		if (grid[i][j - 1] != ' ' && grid[i][j - 1] != data && grid[i][j - 1] != '_')
		{
			done = 1;
			rdata = grid[i][j - 1];
		}
	}
	//i j+1
	if (j + 1 < 200 && done == 0)
	{
		if (' ' == grid[i][j + 1])
		{
			find(i, j + 1);
		}
		if (grid[i][j + 1] != ' ' && grid[i][j + 1] != data && grid[i][j + 1] != '_')
		{
			done = 1;
			rdata = grid[i][j + 1];
		}
	}
}
void fill(int i, int j)
{
	grid[i][j] = rdata;
	//i-1 j
	if (i - 1 >= 0 && (' ' == grid[i - 1][j] || '_' == grid[i - 1][j]))
	{
		fill(i - 1, j);
	}
	//i j-1
	if (j - 1 >= 0 && (' ' == grid[i][j - 1] || '_' == grid[i][j - 1]))
	{
		fill(i, j - 1);
	}
	//i+1 j
	if (i + 1 < 200 && (' ' == grid[i + 1][j] || '_' == grid[i + 1][j]))
	{
		fill(i + 1, j);
	}
	//i j+1
	if (j + 1 < 200 && (' ' == grid[i][j + 1] || '_' == grid[i][j + 1]))
	{
		fill(i, j + 1);
	}
}
void display()
{
	int i;
	for (i = 0; i < grow; i++)
	{
		printf("%s\n", grid[i]);
	}
}
