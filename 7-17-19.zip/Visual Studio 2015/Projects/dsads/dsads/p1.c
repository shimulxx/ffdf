#include<stdio.h>
int cases;
int n;
int m;
int a[100];
int Total;
void testCase()
{
	int i;
	Total = 0;
	scanf("%d", &m);
	for (i = 0; i < m; i++)
	{
		scanf("%d", &a[i]);
		Total += a[i];
	}
}
int solve(int *a,int s,int d,int sum)
{
	if (d == 1)
	{
		sum += a[s];
	}
	if (s == m - 1)
	{
		return negw(Total - 2 * sum);
	}
	return minx(solve(a, s + 1, 0, sum), solve(a, s + 1, 1, sum));
}
int minx(int a, int b)
{
	if (a <= b)
		return a;
	return b;
}
int negw(int a)
{
	if (a < 0)
		return -a;
	return a;
}
int main()
{
	freopen("p1.txt", "r", stdin);
	scanf("%d", &n);
	for (cases = 1; cases <= n; cases++)
	{
		testCase();
		printf("%d\n", solve(a, -1, -1, 0));
	}
}