#include<stdio.h>
#define size 6
#define x 4
float mat[size][size];
int node[size*x];
int level[size*x];
float val[size*x];
int totalNode;
int nodePerTime;
int totalTime;
int loc;
void input();
void display();
void solve();
void initLevel();
void calculate_level(int curL,int maxL);
int main()
{
	int k, t;
	freopen("p1.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solve();
	}
}
void input()
{
	scanf("%d %d %d", &totalNode, &nodePerTime, &totalTime);
	int i, j, k;
	float p;
	for (k = 1; k <= nodePerTime; k++)
	{
		scanf("%d %d %f", &i, &j, &p);
		mat[i][j] = p;
	}
	initLevel();
	node[0] = 0;
	level[0] = 0;
	val[0] = 1.0;
}
void display()
{
	int i, j;
	for (i = 0; i < totalNode; i++)
	{
		for (j = 0; j < totalNode; j++)
		{
			printf("%0.1f ", mat[i][j]);
		}
		printf("\n");
	}
}
void solve()
{
	int maxLevel;
	maxLevel = totalTime / nodePerTime;
	loc = 1;
	calculate_level(0, maxLevel);
}
void calculate_level(int currentIndex, int maxL)
{
	int j, temp, p, k;
	if (level[currentIndex] == maxL)
		return;
	while (1)
	{

	}
	p = 0;
	for (j = 0; j < totalNode; j++)
	{
		if (mat[node[currentIndex]][j] != 0.0)
		{
			if (currentIndex == j)
			{
				//temp = mat[node[currentIndex]][j];
				p = 1;
				continue;
				//val[j] *= mat[node[currentIndex]][j];
			}
			else
			{
				node[loc] = j;
				level[loc] = level[currentIndex] + 1;
				val[j] += val[currentIndex] * mat[node[currentIndex]][j];
				++loc;
			}
		}
	}
	if (p == 1)
	{
		val[currentIndex] *= mat[node[currentIndex]][currentIndex];
		level[currentIndex] += 1;
		for (k = currentIndex + 1; level[k] != -1; k++)
		{
			if (node[currentIndex] == node[k])
			{
				node[k] = -1;
			}
		}
	}
	calculate_level(currentIndex + 1, maxL);
}
void initLevel()
{
	int i;
	for (i = 0; i < size * x; i++)
	{
		level[i] = -1;
	}
}