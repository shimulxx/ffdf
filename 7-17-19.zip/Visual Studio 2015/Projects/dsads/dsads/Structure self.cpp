#include<stdio.h>
typedef struct first
{
	int x, y;
} data;
int main()
{
	data pd[10][10];
	pd[0][0].x = 5;
	
	//printf("%d",pd[0][0].x);

}