#include<stdio.h>
#define SIZE 60
char grid[SIZE][SIZE];
int row;
int col;
int srow;
int scol;
int count;
void input();
void display();
void solveWork();
int findTrap(int *i, int *j);
void solve(int i, int j);
void startFind();
int main()
{
	while (2 == scanf("%d %d", &col, &row))
	{
		input();
		solveWork();
		display();
	}
	return 0;
}
void input()
{
	int i, j;
	for (i = 0; i < row; i++)
	{
		scanf("%s", grid[i]);
	}
}
void display()
{
	printf("%d\n", count);
}
void solve(int i, int j)
{
	grid[i][j] = 'X';
	if (findTrap(&i, &j) == 1)
	{
		return;
	}
	//i-1 j
	if (i - 1 >= 0)
	{
		if ('.' == grid[i - 1][j])
		{
			solve(i - 1, j);
		}
		if ('G' == grid[i - 1][j])
		{
			++count;
			solve(i - 1, j);
		}
	}
	//i+1 j
	if (i + 1 < row)
	{
		if ('.' == grid[i + 1][j])
		{
			solve(i + 1, j);
		}
		if ('G' == grid[i + 1][j])
		{
			++count;
			solve(i + 1, j);
		}
	}
	//i j-1
	if (j - 1 >= 0)
	{
		if ('.' == grid[i][j - 1])
		{
			solve(i, j - 1);
		}
		if ('G' == grid[i][j - 1])
		{
			++count;
			solve(i, j - 1);
		}
	}
	//i j+1
	if (j + 1 < col)
	{
		if ('.' == grid[i][j + 1])
		{
			solve(i, j + 1);
		}
		if ('G' == grid[i][j + 1])
		{
			++count;
			solve(i, j + 1);
		}
	}
}
int findTrap(int *i, int *j)
{
	//i-1 j
	if (*i - 1 >= 0 && 'T' == grid[*i - 1][*j])
		return 1;
	//i+1 j
	if (*i + 1 < row && 'T' == grid[*i + 1][*j])
		return 1;
	//i j-1
	if (*j - 1 >= 0 && 'T' == grid[*i][*j - 1])
		return 1;
	//i j+1
	if (*j + 1 < col && 'T' == grid[*i][*j + 1])
		return 1;
	return 0;
}
void solveWork()
{
	count = 0;
	startFind();
	solve(srow, scol);
}
void startFind()
{
	int i, j, p;
	p = 0;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			if (grid[i][j] == 'P')
			{
				srow = i;
				scol = j;
				p = 1;
				break;
			}
		}
		if (p == 1)
		{
			break;
		}
	}
}