#include<stdio.h>
#define limit 30
int gateNo[4];
int peopleNo[4];
int LEFT1, RIGHT1;
int LEFT2, RIGHT2;
int LEFT3, RIGHT3;
int MAX1, MAX2, MAX3;
int MAX;
int Ans;
int total;
void input();
void solve();
int max2(int a, int b);
int max3(int a, int b, int c);
int absW(int a);
void display(int k);
int main()
{
	int k, t;
	freopen("p7.txt", "r", stdin);
	freopen("pout.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solve();
		display(k);
	}
}
void input()
{
	int k, j, gate, people;
	total = 0;
	for (k = 1; k <= 3; k++)
	{
		scanf("%d %d", &gate, &people);
		total += people;
		gateNo[k] = gate;
		peopleNo[k] = people;
	}
}
void solve()
{
	int L1limit, L2limit, L3limit;
	Ans = 9999999;
	L1limit = 30 - total + 1;
	L2limit = L1limit + peopleNo[1];
	L3limit = L2limit + peopleNo[2];
	LEFT1 = 1;
	while (LEFT1 <= L1limit)
	{
		RIGHT1 = LEFT1 + peopleNo[1] - 1;
		MAX1 = max2(absW(LEFT1-gateNo[1]), absW(RIGHT1-gateNo[1]));
		LEFT2 = RIGHT1 + 1;
		while (LEFT2 <= L2limit)
		{
			RIGHT2 = LEFT2 + peopleNo[2] - 1; 
			MAX2 = max2(absW(LEFT2 - gateNo[2]), absW(RIGHT2 - gateNo[2]));
			LEFT3 = RIGHT2 + 1;
			while (LEFT3 <= L3limit)
			{
				RIGHT3 = LEFT3 + peopleNo[3] - 1;
				MAX3 = max2(absW(LEFT3 - gateNo[3]), absW(RIGHT3 - gateNo[3]));
				MAX = max3(MAX1, MAX2, MAX3);
				if (MAX < Ans)
				{
					Ans = MAX;
				}
				++LEFT3;
			}
	     	++LEFT2;
		}
		++LEFT1;
	}
}
int max2(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}
int min2(int a, int b)
{
	if (a <= b)
		return a;
	return b;
}
int max3(int a, int b, int c)
{
	int x, y;
	x = max2(a, b);
	y = max2(b, c);
	return max2(x, y);
}
int absW(int a)
{
	if (a < 0)
		return -a;
	return a;
}
void display(int k)
{
	printf("#%d %d\n",k, Ans);
}