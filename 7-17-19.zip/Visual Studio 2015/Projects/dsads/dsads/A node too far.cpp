#include<stdio.h>
#define size 32
int adMat[size][size];
int nodeArray[size];
int level[size];
int queue[size];
int visited[size];
int pair;
int totalNode;
int notReachable;
int totalVisit;
int k;
void input();
void solveWork();
int searchArray(int data);
void arrayInsert(int data);
void upDateAd(int d1, int d2);
void calcTotalNode();
void queueOperation(int startNode, int depth);
void display(int node, int ttl);
void initVisited();
void initMat();
int main()
{
	freopen("p7.txt", "r", stdin);
	//freopen("pop.txt", "w", stdout);
	k = 1;
	while (1 == scanf("%d", &pair) && pair != 0)
	{
		initMat();
		input();
		solveWork();
	}
}
void input()
{
	int k, d1, d2;
	for (k = 1; k <= pair; k++)
	{
		scanf("%d %d", &d1, &d2);
		upDateAd(d1, d2);
	}
	calcTotalNode();
	initVisited();
}
void upDateAd(int d1, int d2)
{
	int p1, p2;
	if (searchArray(d1) == -1)
	{
		arrayInsert(d1);
	}
	p1 = searchArray(d1);
	if (searchArray(d2) == -1)
	{
		arrayInsert(d2);
	}
	p2 = searchArray(d2);
	adMat[p1][p2] = 1;
	adMat[p2][p1] = 1;
}
void solveWork()
{
	int d1, d2;
	while (2 == scanf("%d %d", &d1, &d2) && (d1 != 0 || d2 != 0))
	{
		queueOperation(d1, d2);
		/*display(d1, d2);
		initVisited();
		++k;**/
	}
}
int searchArray(int data)
{
	int i;
	for (i = 0; nodeArray[i] != 0; i++)
	{
		if (data == nodeArray[i])
			return i;
	}
	return -1;
}
void arrayInsert(int data)
{
	int i;
	for (i = 0; i < size; i++)
	{
		if (nodeArray[i] == 0)
		{
			nodeArray[i] = data;
			return;
		}
	}
}
void calcTotalNode()
{
	int i;
	for (i = 0; nodeArray[i] != 0; i++);
	totalNode = i;
}
void queueOperation(int startNode, int depth)
{
	int i;
	int left, right;
	level[0] = 0;
	queue[0] = searchArray(startNode);
	left = 0;
	right = 1;
	notReachable = 0;
	totalVisit = 0;
	while(left != right)
	{
		visited[queue[left]] = 1;
		printf("%d ", queue[left]);
		for (i = 0; i < totalNode; i++)
		{
			if (adMat[queue[left]][i] != 0 && !visited[i])
			{
				queue[right] = i;
				level[right] = level[left] + 1;
				++right;
			}
		}
		++left;
	}
	
}
void display(int node, int ttl)
{
	printf("Case %d: %d nodes not reachable from node %d with TTL = %d.\n", k, totalNode-totalVisit, node, ttl);
}
void initVisited()
{
	int i;
	for (i = 0; i < totalNode; i++)
	{
		visited[i] = 0;
	}
}
void initMat()
{
	int i, j;
	for (i = 0; i < size; i++)
	{
		queue[i] = 0;
		for (j = 0; j < size; j++)
		{
			adMat[i][j] = 0;
		}
	}
}