#include<stdio.h>
int cases;
int t;
int p[1000];
int w[1000];
int binary[1000];
int n, m;
int maxcount;
void solve(int i, int sub);
void input();
int maxx(int a, int b);
int solveWork(int w);
int main()
{
	freopen("p5.txt", "r", stdin);
	scanf("%d", &t);
	for (cases = 1; cases <= t; cases++)
	{
		input();
	}
}
void solve(int i, int sub)
{
	int countx = 0, j;
	if (i == n)
	{
		for (j = 0; j < n; j++)
		{
			if (binary[j] == 1)
				countx += p[j];
		}
		if (countx > maxcount)
		{
			maxcount = countx;
		}
		return;
	}
	binary[i] = 0;
	solve(i + 1, sub);
	binary[i] = 1;
	if (w[i] <= sub)
		solve(i + 1, sub - w[i]);
	else
		return;
}

void input()
{
	int i, j, x, wr,total;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d %d", &p[i], &w[i]);
	}
	scanf("%d", &x);
	total = 0;
	for (i = 1; i <= x; i++)
	{
		scanf("%d", &wr);
		total += solveWork(wr);
	}
	printf("%d\n", total);
	
}
int maxx(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}
int solveWork(int w)
{
	maxcount = 0;
	solve(0, w);
	return maxcount;
}

