#include<stdio.h>
int n, grid[101][6];
//int max_value;
void readcase()
{
	int i, j;
	scanf("%d", &n);
	for (i = 1; i <= n; i++)
	{
		for (j = 1; j <= 5; j++)
		{
			scanf("%d", &grid[i][j]);
		}

	}
}
int compare(int x, int y, int z)
{
	int max;

	if (x >= y && x >= z)
	{
		max = x;
	}
	else if (y >= x && y >= z)
	{
		max = y;
	}
	else max = z;
	return max;
}
int solve(int row, int col, int score)
{
	int l, r, m, max;
	if (row >= 1 && col >= 1)
	{
		if (grid[row][col] == 2)
		{
			return score;
		}
		else if (grid[row][col] == 0)
		{
			l = solve(row - 1, col - 1, score);
			r = solve(row - 1, col + 1, score);
			m = solve(row - 1, col, score);
			max = compare(l, r, m);
			return max;
		}
		else if (grid[row][col] == 1)
		{
			l = solve(row - 1, col - 1, score + 1);
			r = solve(row - 1, col + 1, score + 1);
			m = solve(row - 1, col, score + 1);
			max = compare(l, r, m);
			return max;
		}
	}




	//return score;
}
void solvecase()
{
	int left, right, mid, col = 3, max_value;
	left = solve(n, col - 1, 0);
	right = solve(n, col + 1, 0);
	mid = solve(n, col, 0);
	max_value = compare(left, right, mid);
	//return max_value;
	printf("%d\n", max_value);


}
/*void printcase()
{
printf("%d\n", max_value);
}*/
int main()
{
	int t, i;
	freopen("p1.txt", "r", stdin);
	//freopen("pout.txt", "w", stdout);
	scanf("%d", &t);
	for (i = 0; i < t; i++)
	{
		readcase();
		solvecase();
		//printcase();
	}
}