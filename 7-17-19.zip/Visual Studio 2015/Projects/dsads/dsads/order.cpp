#include<stdio.h>
int node;
int edge;
int isFirst;
int adMat[101][101];
int visited[101];
int seq[101];
void input();
void display();
void intAdmatVis();
void floid();
void solve();
int main()
{
	freopen("p1.txt", "r", stdin);
	while (scanf("%d %d", &node, &edge) != EOF && node != 0 && edge != 0)
	{
		isFirst = 1;
		intAdmatVis(); 
		input();
		floid();
		solve();
	}

}
void input()
{
	int i, j, k;
	for (k = 1; k <= edge; k++)
	{
		scanf("%d %d", &i, &j);
		adMat[i][j] = 1;
	}
	
}
void display()
{
	int i, j;
	for (i = 1; i <= node; i++)
	{
		for (j = 1; j <= node; j++)
		{
			printf("%d ", adMat[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}
void intAdmatVis()
{
	int i, j;
	for (i = 1; i <= node; i++)
	{
		for (j = 1; j <= node; j++)
		{
			if (i == j)
			{
				adMat[i][j] = 1;
			}
			else
			{
				adMat[i][j] = 0;
			}
		}
	}
	for (i = 1; i <= node; i++)
	{
		visited[i] = 0;
	}
}
void floid()
{
	int i, j, k;
	for (k = 1; k <= node; k++)
	{
		for (i = 1; i <= node; i++)
		{
			for (j = 1; j <= node; j++)
			{
				if (adMat[i][k] == 1 && adMat[k][j] == 1)
				{
					adMat[i][j] = 1;
				}
			}
		}
	}
}
void solve()
{
	int i, j, p;
	for (i = 1; i <= node; i++)
	{
		for (j = 1; j <= node; j++)
		{
			if (adMat[i][j] == 0 && !visited[j])
			{
				printf("%d ", j);
				visited[j] = 1;
			}
		}
		if (!visited[i])
		{
			printf("%d ", i);
			visited[i] = 1;
		}
	}
	printf("\n");
}