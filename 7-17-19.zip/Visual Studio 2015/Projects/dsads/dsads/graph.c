#include<stdio.h>
int n;
int line;
int p;
char mat[7][3];
void input();
void display();
void intMat();
int main()
{
	int k;
	p = 0;
	freopen("p1.txt", "r", stdin);
	scanf("%d", &n);
	for (k = 1; k <= n; k++)
	{
		input();
	}
}
void input()
{
	line = 0;
	intMat();
	char ch;
	if (p == 0)
	{
		scanf("%c", &ch);
		scanf("%c", &ch);
		while (gets(mat[line]))
		{
			if (mat[line][0] == '\0')
			{
				display();
				break;
			}
			++line;
		}
	}
	else
	{
		while (gets(mat[line]))
		{
			++line;
		}
		display();
	}	
	p = 1;
}
void display()
{
	int i;
	for (i = 0; i < line; i++)
	{
		printf("%s\n", mat[i]);
	}
	//printf("\n");
	intMat();
	line = 0;
}
void intMat()
{
	int i, j;
	for (i = 0; i < 7; i++)
	{
		for (j = 0; j < 3; j++)
		{
			mat[i][j] = 'x';
		}
	}
}