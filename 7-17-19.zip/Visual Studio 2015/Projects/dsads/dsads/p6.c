#include<stdio.h>
int p[100];
int f[100];
int n;
int m;
int Ans;
int dp[101][15000];
void input();
int solve(int i, int val);
void readCase();
void solveCase();
void printCase();
void dpint();
int main()
{
	freopen("p7.txt", "r", stdin);
	while (2 == scanf("%d %d", &m, &n))
	{
		dpint();
		readCase();
		solveCase();
		printCase();
	}
	return 0;
}
int solve(int i, int val)
{
	int left, right;
	printf("%d %d\n", i, val);
	if ((val > m && m < 1800) || (val> m + 200))
	{
		return -1000;
	}
	if (i == n)
	{
		if (val > m && val <= 2000)
		{
			return -1000;
		}
		return 0;
	}
	if (dp[i][val] != -1)
	{
		return dp[i][val];
	}
	left = solve(i + 1, val);
	right = f[i] + solve(i + 1, val + p[i]);
	if (left > right)
		return dp[i][val] = left;
	else
		return dp[i][val] = right;
}
void readCase()
{
	int i;
	for (i = 0; i < n; i++)
		scanf("%d %d", &p[i], &f[i]);
}
void solveCase()
{
	Ans = solve(0, 0);
}
void printCase()
{
	printf("%d\n", Ans);
}
void dpint()
{
	int i, j;
	for (i = 0; i < 101; i++)
	{
		for (j = 0; j < 15000; j++)
		{
			dp[i][j] = -1;
		}
	}
}