#include<stdio.h>
#define size 5
int edge;
int admat[size][size];
int queue[size];
int level[size];
int visited[size];
void input();
void solve();
int main()
{
	freopen("p1.txt", "r", stdin);
	input();
	solve();
}
void input()
{
	int i, j, n, k;
	scanf("%d", &n);
	for (k = 1; k <= n; k++)
	{
		scanf("%d %d", &i, &j);
		admat[i][j] = 1;
		admat[j][i] = 1;
	}
}
void solve()
{
	int i, loc;
	int left, right;
	level[0] = 0;
	queue[0] = 0;
	right = 1;
	for (left = 0; left != right; left++)
	{
		for (i = queue[left]; i < 5; i++)
		{
			if (admat[queue[left]][i] != 0 && !visited[i])
			{
				queue[right] = i;
				level[right] = level[left] + 1;
				++right;
			}
		}
		visited[left] = 1;
		printf("%d", queue[left]);
	}
}