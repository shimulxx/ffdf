#include<stdio.h>
char field[1000][100];
int row[2];
int col[2];
int frow;
int fcol;
int prow;
int p,q;
int r, c;
int count;
int isFirst;
void input();
void initField();
void pointMaker();
void calRowCol();
void initRowColBuf();
void colCounter();
void solve(int i,int j);
void recover();
int main()
{
	int k,t;
	isFirst = 1;
	scanf("%d", &t);
	getchar();
	getchar();
	for (k = 1; k <= t; k++)
	{
		initField();
		if (isFirst == 1)
		{
			input();
			isFirst = 0;
		}
		else
		{
			printf("\n");
			input();
		}
		
	}
	return 0;
}
void input()
{
	frow = 0;
	fcol = 0;
	while (gets(field[frow]) && field[frow][0] != '\0')
	{
		++frow;
	}
	colCounter();
	pointMaker();
}
void pointMaker()
{
	int i, j, k;	
	for (i = 0; i < frow; i++)
	{
		if (field[i][0] != 'L' && field[i][0] != 'W')
		{
			initRowColBuf();
			p = 0;
			for (j = 0; field[i][j] != ' '; j++)
			{
				row[p++] = field[i][j] - 48;
			}
			q = 0;
			for (k = j + 1; field[i][k] != '\0'; k++)
			{
				col[q++]= field[i][k] - 48;
			}
			calRowCol();
		}	
	}
}
void initField()
{
	int i, j;
	for (i = 0; i < 1000; i++)
	{
		for (j = 0; j < 100; j++)
		{
			field[i][j] = '\0';
		}
	}
}
void calRowCol()
{
	count = 0;
	if (p == 1 && q == 1)
	{
		r = row[0];
		c = col[0];
		solve(r-1, c-1);
		printf("%d\n", count);
		recover();
	}
	else if (p == 1 && q != 1)
	{
		col[0] = col[0] * 10 + col[1];
		r = row[0];
		c = col[0];
		solve(r-1, c-1);
		printf("%d\n", count);
		recover();
	}
	else if (p != 1 && q == 1)
	{
		row[0] = row[0] * 10 + row[1];
		r = row[0];
		c = col[0];
		solve(r-1, c-1);
		printf("%d\n", count);
		recover();
	}
	else
	{
		row[0] = row[0] * 10 + row[1];
		col[0] = col[0] * 10 + col[1];
		r = row[0];
		c = col[0];
		solve(r-1, c-1);
		printf("%d\n", count);
		recover();
	}
}
void initRowColBuf()
{
	int i;
	for (i = 0; i < 2; i++)
	{
		row[i] = 0;
		col[i] = 0;
	}
}
void colCounter()
{
	int i;
	for (i = 0; field[0][i] != '\0'; i++);
	fcol = i;
}
void solve(int i, int j)
{
	++count;
	field[i][j] = 'X';
	//i-1 j-1
	if (i - 1 >= 0 && j - 1 >= 0 && 'W' == field[i - 1][j - 1])
	{
		solve(i - 1, j - 1);
	}	
	//i-1 j
	if (i - 1 >= 0 && 'W' == field[i - 1][j])
	{
		solve(i - 1, j);
	}
	//i-1 j+1
	if (i - 1 >= 0 && j + 1 < fcol && 'W' == field[i - 1][j + 1])
	{
		solve(i - 1, j + 1);
	}	
	//i j-1
	if (j - 1 >= 0 && 'W' == field[i][j - 1])
	{
		solve(i, j - 1);
	}		
	//i j+1
	if (j + 1 < fcol && 'W' == field[i][j + 1])
	{
		solve(i, j + 1);
	}	
	//i+1 j-1
	if (i + 1 < frow && j - 1 >= 0 && 'W' == field[i + 1][j - 1])
	{
		solve(i + 1, j - 1);
	}	
	//i+1 j
	if (i + 1 < frow && 'W' == field[i + 1][j])
	{
		solve(i + 1, j);
	}
	//i+1 j+1
	if (i + 1 < frow && j + 1 < fcol && 'W' == field[i + 1][j + 1])
	{
		solve(i + 1, j + 1);
	}
}
void recover()
{
	int i, j;
	for (i = 0; i < frow; i++)
	{
		for (j = 0; j < fcol; j++)
		{
			if (field[i][j] == 'X')
			{
				field[i][j] = 'W';
			}
		}
	}
}
	