#include<stdio.h>
#define size 5
int node;
int edge;
int adMat[size][size];
int color[size];
int visited[size];
void input();
void display();
void initAdMatColor();
int fill(int i, int c);
int solveWork();
void intVisited();
int main()
{
	int k,t;
	freopen("p1.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		initAdMatColor();
		input();
		display();
	}	
	return 0;
}
void input()
{
	int i, j, k;
	scanf("%d %d",&node, &edge);
	for (k = 1; k <= edge; k++)
	{
		scanf("%d %d", &i, &j);
		adMat[i][j] = 1;
		adMat[j][i] = 1;
	}
}
void initAdMatColor()
{
	int i, j;
	for (i = 0; i < node; i++)
	{
		for (j = 0; j < node; j++)
		{
			adMat[i][j] = 0;
		}
	}
	for (i = 0; i < node; i++)
	{
		color[i] = 0;
	}
}
void display()
{
	int i,sum=0;
	if (solveWork() == 1)
	{
		for (i = 0; i < node; i++)
		{
			if (!visited[i])
				++sum;
		}
		printf("%d\n", sum);
	}
	else
	{
		printf("-1\n");
	}
}
int fill(int i, int c)
{
	int j;
	visited[i] = 1;
	if (color[i] == 0)
	{
		color[i] = c;
	}
	else if (color[i] == c)
	{
		return 1;
	}
	else
	{
		return 0;
	}
	for (j = 0; j < node; j++)
	{
		if (adMat[i][j] == 1 && 0 == fill(j, 3 - c))
		{
			return 0;
		}
	}
	return 1;
}
int solveWork()
{
	int i;
	for (i = 0; i < node; i++)
	{
		if (color[i] == 0 && 0 == fill(i, 1))
		{
			return 0;
		}
	}
	return 1;
}
void intVisited()
{
	int i;
	for (i = 0; i < edge; i++)
	{
		visited[i] = 0;
	}
}