#include<stdio.h>
#define size 1005
typedef struct queueProperties
{
	int i, j, len;
} Queue;
Queue Q[size*size];
int mat[size][size];
int visited[size][size];
int R, C, eR, eC, eS;
int total;
int front;
int rear;
void input();
Queue pop();
void solveWork();
void display();
void initQueue();
void solveWork();
int up(int i, int j);
int down(int i, int j);
int left(int i, int j);
int right(int i, int j);
void push(int x, int y, int len);
int isEmpty();
int main()
{
	int k, t;
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork();
		display();
	}
	return 0;
}
void input()
{
	int i, j;
	scanf("%d %d %d %d %d", &R, &C, &eR, &eC, &eS);
	for (i = 0; i < R; i++)
	{
		for (j = 0; j < C; j++)
		{
			scanf("%d", &mat[i][j]);
			if (mat[i][j] != 0)
			{
				visited[i][j] = 0;
			}
			else
			{
				visited[i][j] = 1;
			}
		}
	}
}
int up(int i, int j)
{
	int x;
	x = mat[i][j];
	if (x == 1 || x == 2 || x == 4 || x == 7)
	{
		return 1;
	}
	return 0;
}
int down(int i, int j)
{
	int x;
	x = mat[i][j];
	if (x == 1 || x == 2 || x == 5 || x == 6)
	{
		return 1;
	}
	return 0;
}
int left(int i, int j)
{
	int x;
	x = mat[i][j];
	if (x == 1 || x == 3 || x == 6 || x == 7)
	{
		return 1;
	}
	return 0;
}
int right(int i, int j)
{
	int x;
	x = mat[i][j];
	if (x == 1 || x == 3 || x == 4 || x == 5)
	{
		return 1;
	}
	return 0;
}
void solveWork()
{
	Queue q;
	total = 0;
	initQueue();
	if (mat[eR][eC])
	{
		push(eR, eC, 1);
		visited[eR][eC] = 1;
		++total;
	}
	while (!isEmpty())
	{
		q = pop();
		if (q.len < eS)
		{
			//up i-1,j
			if (q.i - 1 >= 0 && up(q.i, q.j) && down(q.i - 1, q.j) && !visited[q.i - 1][q.j])
			{
				push(q.i - 1, q.j, q.len + 1);
				visited[q.i - 1][q.j] = 1;
				++total;
			}
			//down i+1 j
			if (q.i + 1 < R && down(q.i, q.j) && up(q.i + 1, q.j) && !visited[q.i + 1][q.j])
			{
				push(q.i + 1, q.j, q.len + 1);
				visited[q.i + 1][q.j] = 1;
				++total;
			}
			//left i j-1
			if (q.j - 1 >= 0 && left(q.i, q.j) && right(q.i, q.j - 1) && !visited[q.i][q.j - 1])
			{
				push(q.i, q.j - 1, q.len + 1);
				visited[q.i][q.j - 1] = 1;
				++total;
			}
			//right i j+1
			if (q.j + 1 < C && right(q.i, q.j) && left(q.i, q.j + 1) && !visited[q.i][q.j + 1])
			{
				push(q.i, q.j + 1, q.len + 1);
				visited[q.i][q.j + 1] = 1;
				++total;
			}
		}
	}
}

void display()
{
	printf("%d\n", total);
}
Queue pop()
{
	return Q[front++];
}
void push(int i, int j, int len)
{
	Q[rear].i = i;
	Q[rear].j = j;
	Q[rear].len = len;
	++rear;
}
int isEmpty()
{
	return (front == rear);
}
void initQueue()
{
	front = rear = 0;
}