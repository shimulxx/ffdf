#include<stdio.h>
#define row 200
#define col 5
int mat[row][col];
int R;
int max2(int a, int b);
int max3(int a, int b, int c);
int solve(int i, int j, int sum);
void input();
int main()
{
	int k, t;
	freopen("p1.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		printf("%d\n",solve(R, 2, 0));
	}
}
int max2(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}
int max3(int a, int b, int c)
{
	int x, y;
	x = max2(a, b);
	y = max2(b, c);
	return max2(x, y);
}
void input()
{
	int i, j, n;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < 5; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	mat[i][2] = 0;
	R = i;
}
int solve(int i, int j, int sum)
{
	int x = 0, y = 0, z = 0;
	if (mat[i][j] == 2)
		return sum;
	else
		sum += mat[i][j];
	x = sum;
	//left
	if (i - 1 >= 0 && j - 1 >= 0)
	{
		x = solve(i - 1, j - 1, sum);
	}
	//mid
	if (i - 1 >= 0)
	{
		y = solve(i - 1, j, sum);
	}
	//right
	if (i - 1 >= 0 && j + 1 < 5)
	{
		z = solve(i - 1, j + 1, sum);
	}
	return max3(x, y, z);
}