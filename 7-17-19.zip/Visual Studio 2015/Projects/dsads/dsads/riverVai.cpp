#include<stdio.h>

int T, Ans;
int G1, G2, G3, M1, M2, M3, Case;

void readCase() {
	scanf("%d %d", &G1, &M1);
	scanf("%d %d", &G2, &M2);
	scanf("%d %d", &G3, &M3);
}

int absDif(int x, int y) {
	if (x > y)
		return x - y;
	else
		return y - x;
}
int max(int x, int y) {
	if (x > y)
		return x;
	else
		return y;
}

int minimum(int x, int y) {
	if (x < y)
		return x;
	else
		return y;
}


void solveCase() {
	int i, j, k, left, right, dis1, dis2, dis3, maximum;
	Ans = 30;
	for (i = 1; i + M1 + M2 + M3 - 1 <= 30; i++) {
		left = absDif(G1, i);
		right = absDif(G1, i + M1 - 1);
		dis1 = max(left, right);

		for (j = i + M1; j + M2 + M3 - 1 <= 30; j++) {
			left = absDif(G2, j);
			right = absDif(G2, j + M2 - 1);
			dis2 = max(left, right);

			for (k = j + M2; k + M3 - 1 <= 30; k++) {
				left = absDif(G3, k);
				right = absDif(G3, k + M3 - 1);
				dis3 = max(left, right);

				maximum = max(dis1, dis2);
				maximum = max(maximum, dis3);
				Ans = minimum(maximum, Ans);
			}
		}
	}
}

void printCase() {
	printf("#%d %d\n", ++Case, Ans);
}

int main() {
	Case = 0;
	freopen("p7.txt", "r", stdin);
	scanf("%d", &T);
	while (T>0) {
		readCase();
		solveCase();
		printCase();
		T--;
	}
	return 0;
}
