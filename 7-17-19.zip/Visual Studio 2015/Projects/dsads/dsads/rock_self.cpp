#include<stdio.h>
#define size 100
int mat[size][size];
int dp[size][size];
int n;
int x, y;
void input();
void solveWork(int K);
void solve(int i, int j, int curzero, int maxzero);
int main()
{
	int K,T;
	freopen("p7.txt", "r", stdin);
	freopen("pout.txt", "w", stdout);
	scanf("%d", &T);
	for (K = 1; K <= T; K++)
	{
		input();
		solveWork(K);
	}
}
void input()
{
	int i, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			scanf("%d", &mat[i][j]);
			dp[i][j] = 9999999;
			if (mat[i][j] == 3)
			{
				x = i;
				y = j;
			}
		}
	}
}
void solveWork(int K)
{
	solve(n - 1, 0, 0, 0);
	printf("#%d %d\n",K, dp[x][y]);
}
void solve(int i, int j, int curzero, int maxzero)
{
	if (mat[i][j] == 3)
	{
		if (dp[i][j] > maxzero)
		{
			dp[i][j] = maxzero;
		}
		return;
	}
	if (mat[i][j] == 0)
	{
		++curzero;
	}
	else
	{
		curzero = 0;
	}
	if (curzero > maxzero)
	{
		maxzero = curzero;
	}
	if (maxzero < dp[i][j])
	{
		dp[i][j] = maxzero;
	}
	else
	{
		return;
	}
	//condition horizontal e sudhu 1 hole jaite parbe but vertical er kono condition nai 
	if (i - 1 >= 0)
		solve(i - 1, j, curzero, maxzero);
	if (i + 1 < n)
		solve(i + 1, j, curzero, maxzero);
	if (j - 1 >= 0 && mat[i][j - 1])
		solve(i, j - 1, curzero, maxzero);
	if (j + 1 < n && mat[i][j + 1])
		solve(i, j + 1, curzero, maxzero);	
}