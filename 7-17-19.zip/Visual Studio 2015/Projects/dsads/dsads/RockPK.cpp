#include<stdio.h>
int G[55][55];
int Cost[55][55];
int N, Max;
int X, Y;
int T, Case;

void readCase() {
	scanf("%d", &N);
	int i, j;
	for (i = 0; i < N; i++) {
		for (j = 0; j < N; j++) {
			scanf("%d", &G[i][j]);
			if (G[i][j] == 3) {
				X = i;
				Y = j;
			}
			Cost[i][j] = 10000;
		}
	}
}
void fill(int x, int y, int curzero, int maxzero) {
	if (G[x][y] == 3) {
		if (maxzero<Cost[x][y]) {
			Cost[x][y] = maxzero;
		}
		return;
	}
	if (G[x][y] == 0) {
		curzero++;
		if (curzero > maxzero) {
			maxzero = curzero;
		}
	}
	else if (G[x][y] == 1) {
		curzero = 0;
	}
	if (maxzero < Cost[x][y]) {
		Cost[x][y] = maxzero;
	}
	else
		return;

	if (x - 1 >= 0)
		fill(x - 1, y, curzero, maxzero);
	if (x + 1<N)
		fill(x + 1, y, curzero, maxzero);
	if (y - 1 >= 0 && G[x][y - 1])
		fill(x, y - 1, curzero, maxzero);
	if (y + 1<N&&G[x][y + 1])
		fill(x, y + 1, curzero, maxzero);





}
void solveCase() {
	Max = 0;
	fill(N - 1, 0, 0, 0);
}
void printCase() {
	printf("%d# %d\n", Case, Cost[X][Y]);
}
int main() {
	freopen("p7.txt", "r", stdin);
	freopen("pout.txt", "w", stdout);
	scanf("%d", &T);
	for (Case = 1; Case <= T; Case++) {
		readCase();
		solveCase();
		printCase();
	}
	return 0;
}