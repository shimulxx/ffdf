#include<stdio.h>
char grid[105][105];
int isFirst;
int row;
int col;
int count;
int grow;
int gcol;
void input();
void initGrid();
void gridWork();
void solve(int i,int j);
void solveWork();
int main()
{
	int k, t;
	isFirst = 1;
	freopen("p1.txt", "r", stdin);
	scanf("%d", &t);
	getchar();
	getchar();
	for (k = 1; k <= t; k++)
	{
		initGrid();
		input();
		solveWork();
	}
	printf("\n");
	return 0;
}
void input()
{
	scanf("%d %d", &row, &col);
	getchar();
	gridWork();
}
void initGrid()
{
	int i, j;
	for (i = 0; i < 105; i++)
	{
		for (j = 0; j < 105; j++)
		{
			grid[i][j] = '\0';
		}
	}
}
void gridWork()
{
	int i;
	grow = 0;
	while (gets(grid[grow]) && grid[grow][0] != '\0')
	{
		++grow;
	}
	for (i = 0; grid[0][i] != '\0'; i++);
	gcol = i;
}
void solve(int i,int j)
{
	++count;
	grid[i][j] = '1';
	if (i - 1 >= 0 && '0' == grid[i - 1][j])
	{
		solve(i - 1, j);
	}
	if (j - 1 >= 0 && '0' == grid[i][j - 1])
	{
		solve(i, j - 1);
	}
	if (j + 1 < gcol && '0' == grid[i][j + 1])
	{
		solve(i, j + 1);
	}
	if (i + 1 < grow && '0' == grid[i + 1][j])
	{
		solve(i + 1, j);
	}
}
void solveWork()
{
	count = 0;
	solve(row - 1, col - 1);
	if (isFirst == 1)
	{
		printf("%d", count);
		isFirst = 0;
	}
	else
	{
		printf("\n\n%d", count);
	}
}