#include<stdio.h>
int a[20];
int visited[20];
int row[20];
int col[20];
int n;
int str;
int stc;
int t;
int minCount;
void solve(int i);
int absV(int a);
void input();
int manDistance(int x1, int y1, int x2, int y2);
void visitInt();
void solveRun();
void printWork();
int main()
{
	freopen("p8.txt", "r", stdin);
	//freopen("pout.txt", "w", stdout);
	while (1 == scanf("%d",&t))
	{
		if (t == 0)
			break;
		input();
	}	
	return 0;
}
void work()
{
	int i,sum=0,x=0;
	sum = manDistance(str, stc, row[a[0]], col[a[0]]) + manDistance(str, stc, row[a[n - 1]], col[a[n - 1]]);
	for (i = 0; i < n - 1; i++)
	{
		sum += manDistance(row[a[i]], col[a[i]], row[a[i+1]], col[a[i+1]]);
	}
	if (sum < minCount)
		minCount = sum;
	
}
void solve(int i)
{
	int j;
	if (i == n)
	{
		work();
		return;
	}
	for (j = 0; j < n; j++)
	{
		if (0 == visited[j])
		{
			a[i] = j;
			visited[j] = 1;
			solve(i + 1);
			visited[j] = 0;
		}
	}
}
int absV(int a)
{
	if (a < 0)
		return -a;
	return a;
}
void input()
{
	int i,r,c,x;
	for (x = 1; x <= t; x++)
	{
		scanf("%d %d", &r, &c);
		scanf("%d %d", &str, &stc);
		scanf("%d", &n);
		for (i = 0; i < n; i++)
		{
			scanf("%d %d", &row[i], &col[i]);
		}
		solveRun();
		printWork();
	}
	
}
int manDistance(int x1, int y1, int x2, int y2)
{
	return absV(x1 - x2) + absV(y1 - y2);
}
void visitInt()
{
	int i;
	for (i = 0; i < n; i++)
	{
		visited[i] = 0;
	}
}
void solveRun()
{
	minCount = 400;
	visitInt();
	solve(0);
}
void printWork()
{
	printf("The shortest path has length %d\n", minCount);
}
