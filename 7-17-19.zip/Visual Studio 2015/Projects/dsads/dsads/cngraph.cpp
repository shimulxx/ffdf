#include<stdio.h>
int rowA;
int colA;
int line;
char data[10][3];
void input();
int main()
{
	int t, k;
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		getchar();
		getchar();
	}
}
void input()
{
	line = 0;

}