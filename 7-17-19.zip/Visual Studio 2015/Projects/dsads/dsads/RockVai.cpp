#include<stdio.h>

int mat[1007][1007];
int dp[1007][1007];
int N;
//if(0==grid[x][y]){curzero++;}
//else{cure=0;}
//if(curzero>maxzero){
//maxzero=curzero;
//}
//if(maxzero<dp[x][y])
//dp[x][y]=maxzero;
//else return;


void solve(int x, int y, int curzero, int maxzero) {

	if (0 == mat[x][y]) {
		curzero++;
	}

	else
	{
		curzero = 0;
	}

	if (curzero > maxzero) {
		maxzero = curzero;
	}

	if (maxzero < dp[x][y]) {
		dp[x][y] = maxzero;
	}
	else {

		return;
	}


	if (y + 1 < N && mat[x][y + 1]) {
		solve(x, y + 1, curzero, maxzero);
	}
	if (y - 1 >= 0 && mat[x][y - 1]) {
		solve(x, y - 1, curzero, maxzero);
	}
	if (x + 1 < N) {
		solve(x + 1, y, curzero, maxzero);
	}
	if (x - 1 >= 0) {
		solve(x - 1, y, curzero, maxzero);
	}

}


void solveCase(int tc) {

	scanf("%d", &N);
	int x, y;
	for (int i = 0; i<N; i++) {
		for (int j = 0; j < N; j++) {
			scanf("%d", &mat[i][j]);
			if (mat[i][j] == 3) {
				x = i;
				y = j;
			}
		}
	}

	for (int i = 0; i<N; i++) {
		for (int j = 0; j < N; j++) {
			dp[i][j] = 999999999;
		}
	}
	//freopen("output.txt","w",stdout);
	solve(N - 1, 0, 0, 0);
	printf("#%d %d\n", tc, dp[x][y]);
	/*
	for (int i = 0; i<N; i++){
	for (int j = 0; j < N; j++){
	printf("%d ", dp[i][j]);
	}
	printf("\n");
	}
	*/

}

int main() {

	int tc;
	freopen("p7.txt", "r", stdin);
	freopen("pout.txt", "w", stdout);
	scanf("%d", &tc);
	for (int i = 0; i < tc; i++) {
		solveCase(i + 1);
	}
}