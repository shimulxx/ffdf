#include<stdio.h>
int line;
int total;
int count;
int isFirst;
char data[1100][3];
int adMat[26][26];
int visited[26];
void input();
void display();
void intVisited();
void calcTotal();
void intAdMat();
void dfs(int i);
void solveWork();
void setAdMat();
void solveEx();
int main()
{
	int t, k;
	isFirst = 1;
	scanf("%d", &t);
	getchar();
	getchar();
	for (k = 1; k <= t; k++)
	{
		input();
		solveEx();
		display();
	}
}
void input()
{
	line = 0;
	while (gets(data[line]) && data[line][0] != '\0')
	{
		++line;
	}
	if (isFirst == 1)
	{
		isFirst = 0;
	}
	else
	{
		printf("\n");
	}
}
void display()
{
	printf("%d\n", count);
}
void intVisited()
{
	int i;
	for (i = 0; i < total; i++)
	{
		visited[i] = 0;
	}
}
void calcTotal()
{
	total = data[0][0] - 65 + 1;
}
void intAdMat()
{
	int i, j;
	for (i = 0; i < total; i++)
	{
		for (j = 0; j < total; j++)
		{
			adMat[i][j] = 0;
		}
	}
}
void dfs(int i)
{
	int j;
	visited[i] = 1;
	for (j = 0; j < total; j++)
	{
		if (adMat[i][j] == 1 && !visited[j])
		{
			dfs(j);
		}
	}
}
void solveWork()
{
	int i;
	count = 0;
	for (i = 0; i < total; i++)
	{
		if (visited[i] == 0)
		{
			++count;
			dfs(i);
		}
	}
}
void setAdMat()
{
	int i,r,c;
	for (i = 1; i < line; i++)
	{
		r = data[i][0]-65;
		c = data[i][1]-65;
		adMat[r][c] = 1;
		adMat[c][r] = 1;
	}
}
void solveEx()
{
	calcTotal();
	intVisited();
	intAdMat();
	setAdMat();
	solveWork();
}