#include<stdio.h>
int cases;
int t;
int ob[5][2];
int n, m;
void input()
{
	int i,p;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d %d", &ob[i][0], &ob[i][1]);
	}
	scanf("%d", &p);
	printf("%d\n",solve(0,p,0));
	
}
int maxx(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}
int solve(int i, int sub,int sum)
{
	int max_val,left,right;
	if (sub < 0)
	{
		return 0;
	}
	if (i == n)
	{
		return sum;
	}
	left = solve(i + 1, sub,sum);
	right = solve(i + 1, sub - ob[i][1],sum+ob[i][0]);
	max_val = maxx(left, right);
	return max_val;

}
int main()
{
	freopen("p3.txt", "r", stdin);
	scanf("%d", &t);
	for (cases = 1; cases <= t; cases++)
	{
		input();
	}
}