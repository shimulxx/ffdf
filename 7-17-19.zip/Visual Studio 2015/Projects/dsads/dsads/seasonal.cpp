#include<stdio.h>
char mat[200][201];
int n;
int t;
int done;
void input();
void display(int p);
void pathFind(int i,int x, int y);
void solveWork();
int main()
{
	int k,number;
	number = 1;
	while (1 == scanf("%d", &n) & n != 0)
	{
		done = 0;
		input();
		solveWork();
		display(number++);
	}
	return 0;
}
void input()
{
	int i;
	for (i = 0; i < n; i++)
	{
		scanf("%s", mat[i]);
	}	
}
void display(int p)
{
	if(done == 1)
	   printf("%d B\n", p);
	else
	   printf("%d W\n", p);
}
void pathFind(int i, int x, int y)
{
	if (i == n)
	{
		done = 1;
		return;
	}
	mat[x][y] = 'w';
	if (x - 1 >= 0 && y - 1 >= 0 && 'b' == mat[x - 1][y - 1] && done == 0)
		pathFind(i - 1,x - 1, y - 1);
	if (x - 1 >= 0 && 'b' == mat[x - 1][y] && done == 0)
		pathFind(i - 1,x - 1, y);
	if (y - 1 >= 0 && 'b' == mat[x][y - 1] && done == 0)
		pathFind(i, x, y - 1);
	if (y + 1 < n && 'b' == mat[x][y + 1] && done == 0)
		pathFind(i, x, y + 1);
	if (x + 1 < n  && 'b' == mat[x + 1][y] && done == 0)
		pathFind(i + 1,x + 1, y);
	if (x + 1 < n  && y + 1 < n && 'b' == mat[x + 1][y + 1] && done == 0)
		pathFind(i + 1,x + 1, y + 1);
}
void solveWork()
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (i == 0 && mat[i][j] == 'b')
			{
				pathFind(1, i, j);
			}
		}
	}
}