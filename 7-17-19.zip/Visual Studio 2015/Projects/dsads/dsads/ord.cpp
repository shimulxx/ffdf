#include<stdio.h>
int node;
int edge;
int edgemat[101][2];
int inDeg[101];
int visited[101];
int print[101];
int isFirst;
void input();
void intVisInDeg();
void solve();
void inDegReduce(int data);
int sumOfprint();
int main()
{
	while (2 == scanf("%d %d", &node, &edge) && node != 0)
	{
		intVisInDeg();
		input();
		solve();
	}
	return 0;
}
void input()
{
	int i, j, k;
	for (k = 1; k <= edge; k++)
	{
		scanf("%d %d", &i, &j);
		edgemat[k][0] = i;
		edgemat[k][1] = j;
		++inDeg[j];
	}
	
}
void intVisInDeg()
{
	int i;
	for (i = 1; i <= node; i++)
	{
		visited[i] = 0;
		inDeg[i] = 0;
		print[i] = 0;
	}
}
void solve()
{
	int i;
	isFirst = 1;
	while (1)
	{
		for (i = 1; i <= node; i++)
		{
			if (inDeg[i] == 0 && visited[i] == 0 && print[i] == 0)
			{
				if (isFirst == 1)
				{
					printf("%d", i);
					isFirst = 0;
				}
				else
				{
					printf(" %d", i);
				}
				visited[i] = 1;
				print[i] = 1;
			}
		}
		if (sumOfprint() == node)
		{
			printf("\n");
			break;
		}
		for (i = 1; i <= node; i++)
		{
			if (visited[i] == 1)
			{
				inDegReduce(i);
				visited[i] = 2;
			}

		}
	}
	
}
void inDegReduce(int data)
{
	int i,j;
	for (i = 1; i <= edge; i++)
	{
		if (edgemat[i][0] == data)
		{
			j = edgemat[i][1];
			--inDeg[j];
		}
	}
}
int sumOfprint()
{
	int i, sum = 0;
	for (i = 1; i <= node; i++)
	{
		sum += print[i];
	}
	return sum;
}