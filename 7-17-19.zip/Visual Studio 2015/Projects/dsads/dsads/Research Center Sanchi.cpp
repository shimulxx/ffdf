#include<stdio.h>
int f = 0;
int r = 0;
int N, M, R;

int rx[100];
int ry[100];

typedef struct Node
{
	int x;
	int y;
} np;

np Q[1000];
int mat[100][100];
int d[100][100];
int v[100][100];
int zerocollect[400][5][5];


void pushQ(np x) {
	Q[r] = x;
	r++;
}

np popQ() {

	np t;


	if (r == 0) {
		t.x = -1;
		t.y = -1;
		return t;
	}

	t = Q[0];
	for (int i = 1; i < r; i++) {
		Q[i - 1] = Q[i];
	}
	r--;


	return t;
}


void bfs(int x, int y) {


	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < M; j++) {
			d[i][j] = 99999999;
			v[i][j] = 0;

		}
	}


	np st;
	int dx[4] = { 0, -1, 0, 1 };
	int dy[4] = { 1, 0, -1, 0 };
	st.x = x;
	st.y = y;
	v[x][y] = 1;
	d[x][y] = 0;
	pushQ(st);


	while (1)
	{
		st = popQ();
		//printf("%d %d", st.x, st.y);
		//getchar();

		if (st.x == -1 && st.y == -1) { break; }
		for (int i = 0; i<4; i++)
		{
			int a = st.x + dx[i];
			int b = st.y + dy[i];
			if (a >= 0 && a < N && b >= 0 && b < M && v[a][b] == 0 && mat[a][b] == 1) {
				np pushelement;
				pushelement.x = a;
				pushelement.y = b;
				v[a][b] = 1;
				d[a][b] = d[st.x][st.y] + 1;
				pushQ(pushelement);
			}

			else if (a >= 0 && a < N && b >= 0 && b < M && v[a][b] == 0 && mat[a][b] == 0)
			{
				v[a][b] = 1;
				d[a][b] = d[st.x][st.y] + 1;
			}


		}

	}


}


void input(int tc) {

	scanf("%d%d%d", &N, &M, &R);
	for (int i = 0; i < N; i++) {
		for (int j = 0; j<M; j++) {
			scanf("%d", &mat[i][j]);
		}
	}

	for (int i = 0; i < R; i++) {
		scanf("%d%d", &rx[i], &ry[i]);
	}

	int st;
	for (int i = 0; i < R; i++) {
		int tem = 0;
		bfs(rx[i], ry[i]);
		for (int j = 0; j < N; j++) {
			for (int k = 0; k < M; k++) {

				if (mat[j][k] == 0) {
					zerocollect[tem][0][i] = d[j][k];
					tem++;
					st = tem;
				}

				/*
				if (d[i][j] != 99999999){
				printf("%d ", d[i][j]);
				}
				else
				{
				printf("* ");
				}
				*/
			}
			//printf("\n");
		}
		//printf("\n");
	}

	int min = 99999999;
	int allmax[400];
	for (int i = 0; i<st; i++) {
		int max = -9;
		for (int j = 0; j < R; j++) {
			//printf("%d ", zerocollect[i][0][j]);
			if (zerocollect[i][0][j] > max) {
				max = zerocollect[i][0][j];
			}
		}
		allmax[i] = max;
		//printf("\n");
	}

	for (int i = 0; i < st; i++) {
		//printf("%d \n", allmax[i]);
		if (min > allmax[i]) {
			min = allmax[i];
		}
	}

	if (min == 99999999) {
		printf("#%d -1\n", tc);
	}

	else
	{
		printf("#%d %d\n", tc, min);
	}
}

int main() {
	int tc;
	freopen("p7.txt", "r", stdin);
	freopen("pout.txt", "w", stdout);
	scanf("%d", &tc);
	for (int i = 0; i<tc; i++) {
		input(i + 1);
	}
	return 0;
}