#include<stdio.h>

int m, n, k, T, count, ans;

int arr[201][21];
int visited[21];

void read() {
	int i, j;
	scanf("%d %d %d", &m, &n, &k);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &arr[i][j]);

}

void print() {

	printf("#%d %d\n", count, ans);


}
void solve() {

	int i, j, number = 0, solveCount = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			if (arr[i][j] == visited[j])
				solveCount++;
		}
		if (solveCount == n)
			number++;
		solveCount = 0;
	}
	if (number > ans)
		ans = number;
}
void solveCase() {
	int i, j, x, y, temp;
	ans = 0;
	for (i = 0; i < m; i++) {
		temp = 0;
		for (j = 0; j < n; j++) {
			if (arr[i][j] == 0)
				temp++;
		}

		if (temp <= k && (k - temp) % 2 == 0) {
			for (x = 0; x < n; x++) {
				visited[x] = arr[i][x];
			}
			solve();
		}


	}


}

int main() {
	count = 1;
	freopen("p1.txt", "r", stdin);
	freopen("pout.txt", "w", stdout);
	scanf("%d", &T);
	while (T--) {
		read();
		solveCase();
		print();

		count++;
	}

	return 0;
}