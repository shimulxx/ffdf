#include<stdio.h>
int m;
int n;
int coin[101];
int dp[101][50001];
int total;
int cases;
void input()
{
	int i, j;
	for (i = 0; i < 101; i++)
	{
		for (j = 0; j < 50001; j++)
		{
			dp[i][j] = -1;
		}
	}
	total = 0;
	scanf("%d", &m);
	for (i = 0; i < m; i++)
	{
		scanf("%d", &coin[i]);
		total += coin[i];
	}
}
int minx(int a, int b)
{
	if (a <= b)
		return a;
	return b;
}
int negw(int a)
{
	if (a < 0)
		return -a;
	return a;
}
int solve(int i, int sum1)
{
	int sum2, dif,left,right,mv;
	if (dp[i][sum1] != -1)
		return dp[i][sum1];
	if (i == m)
	{
		sum2 = total - sum1;
		dif = negw(sum1 - sum2);
		dp[i][sum1] = dif;
		return dif;
	}
	left=solve(i + 1, sum1);
	right=solve(i + 1, sum1 + coin[i]);
	mv = minx(left, right);
	dp[i][sum1] = mv;
	return mv;

}
int main()
{
	freopen("p2.txt", "r", stdin);
	scanf("%d", &n);
	for (cases = 1; cases <= n; cases++)
	{
		input();
		printf("%d\n", solve(0, 0));
	}
}