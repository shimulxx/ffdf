#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	char B[101][100];
	char S[101][100];
	int i, j, k, r, c, n, R, C, INCR, INCC, p, pt, q, s;
	cin >> n;
	for (k = 1; k <= n; k++)
	{
		cin >> R >> C;
		i = 0;
		while (gets(B[i]))
		{
			if (i == C)
			{
				break;
			}
			++i;
		}
		cin >> r >> c;
		i = 0;
		while (gets(S[i]))
		{
			if (i == c)
			{
				break;
			}
			++i;
		}
		INCR = 1;
		INCC = 0;
		p = 0;
		//cn=0;
		s = R - r + 1;
		while (INCR <= s)
		{
			for (i = 1; i <= r; i++)
			{
				for (j = 0; j<c; j++)
				{
					pt = i + INCR - 1;
					q = j + INCC;
					if (S[i][j] != B[pt][q])
					{
						p = 1;
						break;
					}
				}
				if (p == 1)
				{
					break;
				}
			}
			if (p == 0)
			{
				cout << "YES" << endl;
				break;
			}
			else
			{
				if (p == 1 && INCC <= C - c)
				{
					++INCC;
					p = 0;
				}
				else
				{
					INCC = 0;
					++INCR;
					p = 0;
				}
			}
		}
	}
	if (INCR>s)
		cout << "NO";
	return 0;
}

