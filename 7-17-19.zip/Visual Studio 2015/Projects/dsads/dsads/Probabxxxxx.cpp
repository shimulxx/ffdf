#include<stdio.h>
#define size 1000
double admat[size][size];
double timeNode[size][size];
double value[size];
int time[size];
int nodeMat[size];
int node;
int edge;
int maxtime;
double maxValue;
int maxNode;
void input();
void solve();
void maxCalculate();
void init();
void display(int k);
int main()
{
	int k, t;
	//freopen("p7.txt", "r", stdin);
	//freopen("pop.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solve();
		maxCalculate();
		display(k);
	}
}
void input()
{
	int i, j, k;
	double p;
	scanf("%d %d %d", &node, &edge, &maxtime);
	init();
	for (k = 1; k <= edge; k++)
	{
		scanf("%d %d %lf", &i, &j, &p);
		admat[i - 1][j - 1] = p;
	}
	timeNode[0][0] = 1;
}
void solve()
{
	int i, j, k;
	maxtime = maxtime / 10;
	for (i = 0; i < maxtime; i++)
	{
		for (j = 0; j < node; j++)
		{
			if (timeNode[i][j] != 0)
			{
				for (k = 0; k < node; k++)
				{
					if (admat[j][k] != 0.0)
					{
						timeNode[i + 1][k] += timeNode[i][j] * admat[j][k];
					}
				}
			}
		}
	}
}
void maxCalculate()
{
	int i;
	maxValue = 0.0;
	for (i = 1; i < node; i++)
	{
		if (timeNode[maxtime][i] > maxValue)
		{
			maxValue = timeNode[maxtime][i];
			maxNode = i;
		}
	}
}
void init()
{
	int i, j;
	for (i = 0; i < node; i++)
	{
		for (j = 0; j < node; j++)
		{
			admat[i][j] = 0.0;
		}
	}
	for (i = 0; i <= maxtime; i++)
	{
		for (j = 0; j < node; j++)
		{
			timeNode[i][j] = 0.0;
		}
	}
}
void display(int k)
{
	printf("#%d %d %0.6lf\n", k, maxNode + 1, maxValue);
}