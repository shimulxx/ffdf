#include<stdio.h>
int w[1000];
int ml[1000];
int dp[1001][6001];
int n;
int t;
int p;
int maxVal;
int solve(int w, int maxcap);
int minx(int a, int b);
int maxx(int a, int b);
void readCase();
void dpint();
int main()
{
	while (1 == scanf("%d", &n))
	{
		if (n == 0)
			break;
		dpint();
		readCase();
	}
	return 0;
}
int solve(int i, int maxcap)
{
	int left, right;
	if (dp[i][maxcap] != -1)
		return dp[i][maxcap];
	if (i == n)
	    return dp[i][maxcap] = 0;
	if (w[i] <= maxcap)
		right = 1 + solve(i + 1, minx(ml[i], maxcap - w[i]));
	else
		right = 0;
	left = solve(i + 1, maxcap);
	return dp[i][maxcap] = maxx(left, right);
}
int minx(int a, int b)
{
	if (a <= b)
		return a;
	return b;
}
void readCase()
{
	int i, data;
	for (i = 0; i < n; i++)
	{
		scanf("%d %d", &w[i], &ml[i]);
	}
	printf("%d\n", solve(0, 6000));
	
}
int maxx(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}
void dpint()
{
	int i, j;
	for (i = 0; i < 1001; i++)
	{
		for (j = 0; j < 6001; j++)
		{
			dp[i][j] = -1;
		}
	}
}