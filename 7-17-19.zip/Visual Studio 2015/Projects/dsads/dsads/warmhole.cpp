#include<stdio.h>
#define size 5
int visited[size];
int a[size];
int mrowData[size];
int mcolData[size];
int wrowData[size];
int wcolData[size];
int wValData[size];
int n;
int m;
int w;
int ans;
void input();
void solve(int p, int i, int j, int dept);
int pointCheck(int i);
void display();
int main()
{
	int k, t;
    input();
	solve(1,1,1,0);
}
void input()
{
	w = 3;
}
void solve(int p,int i,int j,int dept)
{
	int k, s;
	/*for (s = 1; s < p; s++)
	{
		printf("%d", a[s]);
	}
	if(p > 1)
	   printf("\n");*/
	if (p == w + 1)
	{
		return;
	}
	for (k = 1; k <= w; k++)
	{
		if (!visited[k])
		{
			a[p] = k;
			printf("%d", a[p]);
			printf("\n");
.
            visited[k] = 1;
			solve(p + 1,1,1,0);
			visited[k] = 0;
		}
	}
}
void display()
{
	int i;
	for (i = 1; i <= w; i++)
	{
		printf("%d", a[i]);
	}
	printf("\n");
}
int pointCheck(int i)
{
	if (wrowData[i] == wcolData[i])
	{
		return 1;
	}
	return 0;
}