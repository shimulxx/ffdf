#include<stdio.h>
#define size 20
int visited[size];
int a[size];
int mrowData[size];
int mcolData[size];
int wrowData[size];
int wcolData[size];
int wValData[size];
int n;
int m;
int w;
int ans;
void intVisited();
void input();
void solve(int i, int j, int dis);
int manDistance(int x1, int y1, int x2, int y2);
void display(int k);
int absV(int a);
int main()
{
	int k, t;
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		intVisited();
		solve(1, 1, 0);
		display(k);
	}
}
void input()
{
	int k;
	scanf("%d %d %d", &n, &m, &w);
	for (k = 1; k <= m; k++)
	{
		scanf("%d %d", &mrowData[k], &mcolData[k]);
	}
	for (k = 1; k <= w; k++)
	{
		scanf("%d %d %d", &wrowData[k], &wcolData[k], &wValData[k]);
	}
	ans = 2 * (n - 1);
}
void solve(int i, int j, int dis)
{
	int k, dis1, dis2, minDis;
	minDis = manDistance(n, n, i, j) + dis;
	//minDis = n - i + n - j + dis;
	if (minDis < ans)
	{
		ans = minDis;
	}
	if (dis > ans)
	{
		return;
	}
	for (k = 1; k <= w; k++)
	{
		if (!visited[k])
		{
			visited[k] = 1;
			dis1 = manDistance(i, j, mrowData[wrowData[k]], mcolData[wrowData[k]]);
			dis2 = manDistance(i, j, mrowData[wcolData[k]], mcolData[wcolData[k]]);
			if (dis1 < dis2)
			{
				solve(mrowData[wcolData[k]], mcolData[wcolData[k]], dis + dis1 + wValData[k]);
			}
			else
			{
				solve(mrowData[wrowData[k]], mcolData[wrowData[k]], dis + dis2 + wValData[k]);
			}
            visited[k] = 0;
	    }
    }
}
void display(int k)
{
	printf("#%d %d\n", k, ans);
}
void intVisited()
{
	int i;
	for (i = 1; i <= w; i++)
	{
		visited[i] = 0;
	}
}
int absV(int a)
{
	if (a < 0)
		return -a;
	return a;
}
int manDistance(int x1, int y1, int x2, int y2)
{
	return absV(x1 - x2) + absV(y1 - y2);
}