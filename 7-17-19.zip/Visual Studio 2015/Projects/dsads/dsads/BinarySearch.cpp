#include<stdio.h>
// X = A*N + B*log(N) + C*N*N*N
// Input A B C X
// Output N
// 1 <= A <= 100
// 1 <= B <= 100
// 0 <= C <= 100
// 0 <= X <= 10^15
// N must be integer
// 0 <= N <= 10^13
long long int A;
long long int B;
long long int C;
long long int X;
long long int N;
int log(long long n);
void input();
void calculation();
int main()
{
	int k,t;
	freopen("p1.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
	}
}
int log(long long n)
{
	double d = (double)n;
	int value = 0;
	while (d >= 2.71828) {
		d /= 2.71828;
		value++;
	}
	return value;
}
void input()
{
	scanf("%lld %lld %lld %lld", &A, &B, &C, &X);
	calculation();
}
void calculation()
{
	register long long int data;
	data = 0;
	N = 0;
	while (data != X)
	{
		data = A*N + B*log(N) + C*N*N*N;
		printf("%lld %lld\n", data,N);
		++N;
	}
}