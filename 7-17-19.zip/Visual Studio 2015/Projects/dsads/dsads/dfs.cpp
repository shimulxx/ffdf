#include<stdio.h>
int admat[5][5];
int visited[5];
int count;
void matInt();
void visitInt();
void solveWork();
void dfs(int i);
void display();
void input();
int main()
{
	freopen("p1.txt", "r", stdin);
	matInt();
	visitInt();
	input();
	solveWork();
	display();
}
void matInt()
{
	int i, j;
	for (i = 0; i < 5; i++)
	{
		for (j = 0; j < 5; j++)
		{
			admat[i][j] = 0;
		}
	}
}
void visitInt()
{
	int i;
	for (i = 0; i < 5; i++)
	{
		visited[i] = 0;
	}
}
void solveWork()
{
	int i;
	count = 0;
	for (i = 0; i < 5; i++)
	{
		if (visited[i] == 0)
		{
			++count;
			dfs(i);
		}
	}
}
void dfs(int i)
{
	int j;
	visited[i] = 1;
	for (j = 0; j < 5; j++)
	{
		if (admat[i][j] == 1 && !visited[j])
		{
			dfs(j);
		}
	}
}
void display()
{
	printf("%d", count);
}
void input()
{
	int n,k,r,c;
	scanf("%d", &n);
	for (k = 1; k <= n; k++)
	{
		scanf("%d %d", &r, &c);
		admat[r][c] = 1;
		admat[c][r] = 1;
	}
}