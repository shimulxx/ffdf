#include<stdio.h>
#define size 50
int mat[size][size];
int dp[size][size];
int rpR[size];
int rpC[size];
int R, C, RearP;
int x, y;
int MAX;
int MIN;
void input();
void solve(int i, int j, int dist);
void solveWork();
void initDp();
void display(int k);
int main()
{
	int k, t;
	freopen("p7.txt", "r", stdin);
	//freopen("pout.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork();
		//display(k);
	}
}
void input()
{
	int i, j, k;
	scanf("%d %d %d", &R, &C, &RearP);
	for (i = 0; i < R; i++)
	{
		for (j = 0; j < C; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	for (k = 1; k <= RearP; k++)
	{
		scanf("%d %d", &rpR[k - 1], &rpC[k - 1]);
	}
}
void solve(int i, int j, int dist)
{
	if (i == x && j == y)
	{
		if (dp[i][j] > dist)
		{
			dp[i][j] = dist;
		}
		return;
	}
	if (dp[i][j] > dist)
	{
		dp[i][j] = dist;
	}
	else
	{
		return;
	}
	//up i-1 j
	if (i - 1 >= 0)
	{
		solve(i - 1, j, dist + 1);
	}
	//down i+1 j
	if (i + 1 < R)
	{
		solve(i + 1, j, dist + 1);
	}
	//left i j-1
	if (j - 1 >= 0)
	{
		solve(i, j - 1, dist + 1);
	}
	//right i j+1
	if (j + 1 < C)
	{
		solve(i, j + 1, dist + 1);
	}
}
void solveWork()
{
	int i, j, k;
	MIN = 999999;
	for (i = 0; i < R; i++)
	{
		for (j = 0; j < C; j++)
		{
			if (mat[i][j] == 0)
			{
				MAX = -999999;
				initDp();
				solve(i, j, 0);
				for (k = 0; k < RearP; k++)
				{
					printf("%d %d %d\n", i, j, dp[rpR[k]][rpC[k]]);
					if (dp[rpR[k]][rpC[k]] > MAX)
					{
						MAX = dp[rpR[k]][rpC[k]];
					}
				}
				if (MAX < MIN)
				{
					MIN = MAX;
				}
			}
		}
	}
}
void initDp()
{
	int i, j;
	for (i = 0; i < R; i++)
	{
		for (j = 0; j < C; j++)
		{
			dp[i][j] = 999999;
		}
	}
}
void display(int k)
{
	if (MIN == 999999)
	{
		printf("#%d -1\n",k);
	}
	else
	{
		printf("#%d %d\n", k, MIN);
	}
}