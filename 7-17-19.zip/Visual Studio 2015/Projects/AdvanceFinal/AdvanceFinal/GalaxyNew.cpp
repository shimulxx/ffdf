#include<stdio.h>
#define size 100
int n, m, w;
int mrow[size], mcol[size];
int wrow[size], wcol[size], wlen[size];
int visited[size];
int ans;
void input();
void solveWork(int k);
void solve(int i, int j, int dis);
int absW(int a);
int manDistance(int x1,int y1,int x2,int y2);
void initVisited();
int main()
{
	int k, t;
	freopen("GalaxyInput.txt", "r", stdin);
	freopen("GalaxyOutputNew.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork(k);
	}
}
void input()
{
	int k;
	scanf("%d %d %d", &n, &m, &w);
	for (k = 1; k <= m; k++)
	{
		scanf("%d %d", &mrow[k], &mcol[k]);
	}
	for (k = 1; k <= w; k++)
	{
		scanf("%d %d %d", &wrow[k], &wcol[k], &wlen[k]);
	}
}
void solveWork(int k)
{
	initVisited();
	ans = 2 * n - 1;
	solve(1, 1, 0);
	printf("#%d %d\n", k, ans);
}
void solve(int i, int j, int dis)
{
	int k, dis1, dis2, totalDis;
	totalDis = manDistance(n, n, i, j) + dis;
	if (totalDis < ans)
	{
		ans = totalDis;
	}
	if (dis > ans)
	{
		return;
	}
	for (k = 1; k <= w; k++)
	{
		if (!visited[k])
		{
			visited[k] = 1;
			dis1 = manDistance(i, j, mrow[wrow[k]], mcol[wrow[k]]);
			dis2 = manDistance(i, j, mrow[wcol[k]], mcol[wcol[k]]);
			if (dis1 < dis2)
			{
				solve(mrow[wcol[k]], mcol[wcol[k]], dis + dis1 + wlen[k]);
			}
			else
			{
				solve(mrow[wrow[k]], mcol[wrow[k]], dis + dis2 + wlen[k]);
			}
			visited[k] = 0;
		}
	}
}
int absW(int a)
{
	if (a < 0)
		return -a;
	return a;
}
int manDistance(int x1, int y1, int x2, int y2)
{
	return absW(x1 - x2) + absW(y1 - y2);
}
void initVisited()
{
	int i;
	for (i = 1; i <= w; i++)
	{
		visited[i] = 0;
	}
}