#include<stdio.h>
#define size 1000
double adMat[size][size];
double timeMat[size][size];
int node, edge, time,desiredNode;
double p;
double max;
void input();
void initMat();
void solveWork(int s);
int main()
{
	int k, t;
	freopen("ProbabilityInput.txt", "r", stdin);
	freopen("ProbabilityOutputNew.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork(k);
	}
}
void input()
{
	int i, j, k;
	scanf("%d %d %d", &node, &edge, &time);
	time = time / 10;
	initMat();
	for (k = 1; k <= edge; k++)
	{
		scanf("%d %d %lf", &i, &j, &p);
		adMat[i - 1][j - 1] = p;
	}
	timeMat[0][0] = 1.0;
}
void initMat()
{
	int i,j;
	for (i = 0; i < node; i++)
	{
		for (j = 0; j < node; j++)
		{
			adMat[i][j] = 0.0;
		}
	}
	for (i = 0; i <= time; i++)
	{
		for (j = 0; j < node; j++)
		{
			timeMat[i][j] = 0.0;
		}
	}
}
void solveWork(int s)
{
	int i, j, k;
	for (i = 0; i < time; i++)
	{
		for (j = 0; j < node; j++)
		{
			if (timeMat[i][j] != 0.0)
			{
				for (k = 0; k < node; k++)
				{
					if (adMat[j][k] != 0.0)
					{
						timeMat[i + 1][k] += timeMat[i][j] * adMat[j][k];
					}
				}
			}
		}
	}
	//max = timeMat[time][0];
	max = 0.0;
	for (i = 1; i < node; i++)
	{
		if (timeMat[time][i] > max)
		{
			max = timeMat[time][i];
			desiredNode = i + 1;
		}
	}
	printf("#%d %d %0.6lf\n", s, desiredNode, max);
}