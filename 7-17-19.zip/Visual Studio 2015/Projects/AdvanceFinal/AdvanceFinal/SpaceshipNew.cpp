#include<stdio.h>
#define size 200
int mat[size][5];
int R;
void input();
int max2(int a, int b);
int max3(int a, int b, int c);
int solve(int i, int j, int sum, int life);
int main()
{
	int k, t;
	freopen("spaceshipInput.txt", "r", stdin);
	freopen("spaceshipOutputNew.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		printf("#%d %d\n", k, solve(R, 2, 0, 6));
	}
}
void input()
{
	int i, j, r;
	scanf("%d", &r);
	for (i = 0; i < r; i++)
	{
		for (j = 0; j < 5; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	mat[i][2] = 0;
	R = i;
}
int max2(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}
int max3(int a, int b, int c)
{
	int x, y;
	x = max2(a, b);
	y = max2(b, c);
	return max2(x, y);
}
int solve(int i, int j, int sum, int life)
{
	int x = 0, y = 0, z = 0;
	if (mat[i][j] == 2)
	{
		if (life == 0)
			return sum;
		if (life == 6)
			life = life - 1;
	}
	else
		sum += mat[i][j];
	x = sum;
	if (life > 0 && life < 6)
		--life;
	//left up i-1 j-1
	if (i - 1 >= 0 && j - 1 >= 0)
	{
		x = solve(i - 1, j - 1, sum, life);
	}
	//up i-1 j
	if (i - 1 >= 0)
	{
		y = solve(i - 1, j, sum, life);
	}
	//right up i-1 j+1
	if (i - 1 >= 0 && j + 1 < 5)
	{
		z = solve(i - 1, j + 1, sum, life);
	}
	return max3(x, y, z);
}