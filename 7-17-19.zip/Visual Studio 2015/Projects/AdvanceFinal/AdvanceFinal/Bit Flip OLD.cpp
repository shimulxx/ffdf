#include<stdio.h>
int row;
int col;
int k;
int mat[100][100];
void input();
void display(int p);
int maxV;
int rowZeroCount(int i);
int checkSameRow(int i, int j);
void solve();
int main()
{
	int t;
	int p;
	freopen("bitflipInput.txt", "r", stdin);
	freopen("bitflipOutputOld.txt", "w", stdout);
	scanf("%d", &t);
	for (p = 1; p <= t; p++)
	{
		input();
		solve();
		display(p);
	}
	return 0;
}
void input()
{
	int i, j;
	scanf("%d %d %d", &row, &col, &k);
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
}
void display(int p)
{
	printf("#%d %d\n", p, maxV);
}
int rowZeroCount(int i)
{
	int j, sum = 0;
	for (j = 0; j < col; j++)
	{
		if (mat[i][j] == 0)
		{
			++sum;
		}
	}
	return sum;
}
int checkSameRow(int i, int j)
{
	int k;
	for (k = 0; k < col; k++)
	{
		if (mat[i][k] != mat[j][k])
			break;
	}
	if (k == col)
		return 1;
	return 0;
}
void solve()
{
	int i, j, count, noOfRow;
	maxV = 0;
	for (i = 0; i < row; i++)
	{
		noOfRow = 0;
		count = rowZeroCount(i);
		if (k >= count && (k - count) % 2 == 0)
		{
			for (j = i; j < row; j++)
			{
				noOfRow += checkSameRow(i, j);
			}
		}
		else
		{
			continue;
		}
		if (noOfRow > maxV)
		{
			maxV = noOfRow;
		}
	}
}
