#include<stdio.h>
#define row 200
#define col 5
int mat[row][col];
int R;
int max2(int a, int b);
int max3(int a, int b, int c);
int solve(int i, int j, int sum, int life);
void input();
void display(int k);
int main()
{
	int k, t;
	freopen("spaceshipInput.txt", "r", stdin);
	//freopen("spaceshipOutputOld.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		display(k);
	}
}
int max2(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}
int max3(int a, int b, int c)
{
	int x, y;
	x = max2(a, b);
	y = max2(b, c);
	return max2(x, y);
}
void input()
{
	int i, j, n;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < 5; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	mat[i][2] = 0;
	R = i;
}
int solve(int i, int j, int sum, int life)
{
	int x = 0, y = 0, z = 0;
	if (mat[i][j] == 2 && life == 0)
		return sum;
	if (mat[i][j] == 2 && life == 6)
		life = life - 1;
	if (life > 0 && life < 6)
		--life;
	if (mat[i][j] != 2)
		sum += mat[i][j];
	x = sum; //important !
	//left
	if (i - 1 >= 0 && j - 1 >= 0)
	{
		x = solve(i - 1, j - 1, sum, life);
	}
	//mid
	if (i - 1 >= 0)
	{
		y = solve(i - 1, j, sum, life);
	}
	//right
	if (i - 1 >= 0 && j + 1 < 5)
	{
		z = solve(i - 1, j + 1, sum, life);
	}
	return max3(x, y, z);
}
void display(int k)
{
	printf("#%d %d\n", k, solve(R, 2, 0, 6));
}