#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<math.h>
int n;
int row[151], col[151];
int mVrow[151], mVcol[151];
int visited[151];
int a[151];
double minVal;
void input();
void display(int j);
void work();
void solve(int i);
void intVisit();
void distCalc();
double euDist(int x1, int y1, int x2, int y2);
int main()
{
	int i = 0;
	freopen("GettingInlineInput.txt", "r", stdin);
	freopen("GettingInlineOutput.txt", "w", stdout);
	while (1 == scanf("%d", &n) && n != 0)
	{
		minVal = 999999;
		input();
		work();
		display(++i);
	}
	return 0;
}
void input()
{
	int i;
	for (i = 0; i < n; i++)
	{
		scanf("%d %d", &row[i], &col[i]);
	}
}
void display(int j)
{
	int i;
	double x;
	printf("**********************************************************\n");
	printf("Network #%d\n", j);
	for (i = 0; i < n - 1; i++)
	{
		x = euDist(mVrow[i], mVcol[i], mVrow[i + 1], mVcol[i + 1]);
		printf("Cable requirement to connect (%d,%d) to (%d,%d) is %0.2f feet.\n", mVrow[i], mVcol[i], mVrow[i + 1], mVcol[i + 1], x);
	}
	printf("Number of feet of cable required is %0.2f.\n", minVal);
}
void swapx(int loc0, int loci)
{
	int loc0RowData, loc0ColData;
	loc0RowData = row[0];
	loc0ColData = col[0];
	row[0] = row[loci];
	col[0] = col[loci];
	row[loci] = loc0RowData;
	col[loci] = loc0ColData;
}
void work()
{
	int i;
	for (i = 0; i < n; i++)
	{
		swapx(0, i);
		intVisit();
		solve(0);
		swapx(i, 0);
	}
}
void solve(int i)
{
	int j;
	if (i == n)
	{
		distCalc();
		return;
	}
	for (j = 0; j < n; j++)
	{
		if (0 == visited[j])
		{
			a[i] = j;
			visited[j] = 1;
			solve(i + 1);
			visited[j] = 0;
		}
	}
}
void intVisit()
{
	int i;
	for (i = 0; i < n; i++)
	{
		visited[i] = 0;
	}
}
void distCalc()
{
	int i;
	double sum = 0;
	for (i = 0; i < n - 1; i++)
	{

		sum += euDist(row[a[i]], col[a[i]], row[a[i + 1]], col[a[i + 1]]);
	}
	if (sum < minVal)
	{
		minVal = sum;
		for (i = 0; i < n; i++)
		{
			mVrow[i] = row[a[i]];
			mVcol[i] = col[a[i]];
		}
	}
}
double euDist(int x1, int y1, int x2, int y2)
{
	int d;
	double data;
	d = (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2);
	data = sqrt(d) + 16;
	return data;
}