#include<stdio.h>
#define size 100
int mat[size][size];
int r, c, k;
int maxV;
void input();
void solveWork();
int checkSameRow(int i, int j);
int ZeroCount(int i);
void display(int p);
int main()
{
	int p, t;
	freopen("bitflipInput.txt", "r", stdin);
	freopen("bitflipOutputNew.txt", "w", stdout);
	scanf("%d", &t);
	for (p = 1; p <= t; p++)
	{
		input();
		solveWork();
		display(p);
	}
}
void input()
{
	int i, j;
	scanf("%d %d %d", &r, &c, &k);
	for (i = 0; i < r; i++)
	{
		for (j = 0; j < c; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
}
void solveWork()
{
	int i, j,rowCount,nOfZero;
	maxV = 0;
	for (i = 0; i < r; i++)
	{
		rowCount = 0;
		nOfZero = ZeroCount(i);
		if (k >= nOfZero && (k - nOfZero) % 2 == 0)
		{
			for (j = i; j < r; j++)
			{
				rowCount += checkSameRow(i, j);
			}
		}
		else
		{
			continue;
		}
		if (rowCount > maxV)
			maxV = rowCount;
	}
}
int checkSameRow(int i, int j)
{
	int k;
	for (k = 0; k < c; k++)
	{
		if (mat[i][k] != mat[j][k])
			return 0;
	}
	return 1;
}
int ZeroCount(int i)
{
	int j,count=0;
	for (j = 0; j < c; j++)
	{
		if (mat[i][j] == 0)
		{
			++count;
		}
	}
	return count;
}
void display(int p)
{
	printf("#%d %d\n", p, maxV);
}