#include<stdio.h>
int gateNo[4], peopleNo[4];
int LEFT1, RIGHT1;
int LEFT2, RIGHT2;
int LEFT3, RIGHT3;
int MAX1, MAX2, MAX3, MAX;
int ans,totalPeople;
void input();
int max2(int a, int b);
int max3(int a, int b, int c);
int absW(int a);
void solveWork(int k);
int main()
{
	int k, t;
	freopen("RiverInput.txt", "r", stdin);
	freopen("RiverOutputNew.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork(k);
	}
}
int max2(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}
int max3(int a, int b, int c)
{
	int x, y;
	x = max2(a, b);
	y = max2(b, c);
	return max2(x, y);
}
int absW(int a)
{
	if (a < 0)
		return -a;
	return a;
}
void input()
{
	int i;
	totalPeople = 0;
	for (i = 1; i <= 3; i++)
	{
		scanf("%d %d", &gateNo[i], &peopleNo[i]);
		totalPeople += peopleNo[i];
	}
}
void solveWork(int k)
{
	int L1LIMIT, L2LIMIT, L3LIMIT;
	ans = 30;
	L1LIMIT = 30 - totalPeople + 1;
	L2LIMIT = L1LIMIT + peopleNo[1];
	L3LIMIT = L2LIMIT + peopleNo[2];
	LEFT1 = 1;
	while (LEFT1 <= L1LIMIT)
	{
		RIGHT1 = LEFT1 + peopleNo[1] - 1;
		MAX1 = max2(absW(gateNo[1] - LEFT1), absW(gateNo[1] - RIGHT1));
		LEFT2 = RIGHT1 + 1;
		while (LEFT2 <= L2LIMIT)
		{
			RIGHT2 = LEFT2 + peopleNo[2] - 1;
			MAX2 = max2(absW(gateNo[2] - LEFT2), absW(gateNo[2] - RIGHT2));
			LEFT3 = RIGHT2 + 1;
			while (LEFT3 <= L3LIMIT)
			{
				RIGHT3 = LEFT3 + peopleNo[3] - 1;
				MAX3 = max2(absW(gateNo[3] - LEFT3), absW(gateNo[3] - RIGHT3));
				MAX = max3(MAX1, MAX2, MAX3);
				if (MAX < ans)
				{
					ans = MAX;
				}
				++LEFT3;
			}
			++LEFT2;
		}
		++LEFT1;
	}
	printf("#%d %d\n", k, ans);
}