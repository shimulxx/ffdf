#include<stdio.h>
#define size 30
int edge;
int done;
int min;
int data[size];
int visited[size];
int sRval, sCval;
int dRval, dCval;
int row[size];
int col[size];
void input();
void solve(int i, int d);
int manDistance(int x1, int y1, int x2, int y2);
int distCalc(int loc1, int loc2);
void solveWork();
void initVisited();
int absW(int a);
int main()
{
	int k, t;
	freopen("tspInput.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork();
	}
	return 0;
}
void solve(int i, int d)
{
	int j;
 	if (i > 1)
	{
		d += distCalc(data[i - 2], data[i - 1]);
	}
	if (done == 1 && d > min)
	{
		return;
	}
	if (i == edge - 1)
	{
		done = 1;
		d += manDistance(row[data[i - 1]], col[data[i - 1]], row[i], col[i]);
		if (d < min)
		{
			min = d;
		}
		return;
	}
	for (j = 1; j < edge - 1; j++)
	{
		if (!visited[j])
		{
			data[i] = j;
			visited[j] = 1;
			solve(i + 1, d);
			visited[j] = 0;
		}
	}
}
void input()
{
	int i;
	scanf("%d", &edge);
	scanf("%d %d %d %d", &sRval, &sCval, &dRval, &dCval);
	for (i = 1; i <= edge; i++)
	{
		scanf("%d %d", &row[i], &col[i]);
	}
	row[0] = sRval;
	col[0] = sCval;
	row[i] = dRval;
	col[i] = dCval;
	edge += 2;
}
int manDistance(int x1, int y1, int x2, int y2)
{
	int data;
	data = absW(x1 - x2) + absW(y1 - y2);
	return data;
}
void solveWork()
{
	int i;
	done = 0;
	min = 999999;
	solve(1, 0);
	printf("%d\n", min);
}
int distCalc(int loc1, int loc2)
{
	int data;
	data = manDistance(row[loc1], col[loc1], row[loc2], col[loc2]);
	return data;
}
void initVisited()
{
	int i;
	for (i = 0; i < edge; i++)
	{
		visited[i] = 0;
	}
}
int absW(int a)
{
	if (a < 0)
		return -a;
	return a;
}