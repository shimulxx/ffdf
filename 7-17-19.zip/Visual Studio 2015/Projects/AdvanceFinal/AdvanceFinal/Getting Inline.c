#include<stdio.h>
#include<math.h>
#define size 160
int edge;
int done;
double min;
int data[size];
int visited[size];
int row[size];
int col[size];
int mrow[size];
int mcol[size];
void input();
void solve(int i, double d);
void swapWork(int locF, int locD);
double euDistance(int x1, int y1, int x2, int y2);
double distCalc(int loc1, int loc2);
void solveWork(int k);
void initVisited();
int main()
{
	int k;
	k = 1;
	while (1 == scanf("%d", &edge) && edge != 0)
	{
		input();
		solveWork(k);
		++k;
	}
	return 0;
}
void solve(int i, double d)
{
	int j;
	if (i > 1)
	{
		d += distCalc(data[i - 2], data[i - 1]);
	}
	if (done == 1 && d > min)
	{
		return;
	}
	if (i == edge)
	{
		done = 1;
		if (d < min)
		{
			min = d;
			for (j = 0; j < edge; j++)
			{
				mrow[j] = row[data[j]];
				mcol[j] = col[data[j]];
			}
		}
		return;
	}
	for (j = 1; j < edge; j++)
	{
		if (!visited[j])
		{
			data[i] = j;
			visited[j] = 1;
			solve(i + 1, d);
			visited[j] = 0;
		}
	}
}
void input()
{
	int i;
	for (i = 1; i <= edge; i++)
	{
		scanf("%d %d", &row[i - 1], &col[i - 1]);
	}
}
double euDistance(int x1, int y1, int x2, int y2)
{
	int data;
	double rValue;
	if (x1 == x2 && y1 == y2)
	{
		return 0;
	}
	data = (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2);
	rValue = sqrt(data);
	return rValue + 16;
}
void swapWork(int locF, int locD)
{
	int tmpR, tmpC;
	tmpR = row[locF];
	tmpC = col[locF];
	row[locF] = row[locD];
	col[locF] = col[locD];
	row[locD] = tmpR;
	col[locD] = tmpC;
}
void solveWork(int k)
{
	int i;
	done = 0;
	min = 999999;
	for (i = 1; i < edge; i++)
	{
		swapWork(0, i);
		initVisited();
		solve(1, 0);
		swapWork(i, 0);
	}
	printf("**********************************************************\n");
	printf("Network #%d\n", k);
	for (i = 0; i < edge - 1; i++)
	{
		printf("Cable requirement to connect (%d,%d) to (%d,%d) is %0.2f feet.\n", mrow[i], mcol[i], mrow[i + 1], mcol[i + 1], euDistance(mrow[i], mcol[i], mrow[i + 1], mcol[i + 1]));
	}
	printf("Number of feet of cable required is %0.2f.\n", min);
}
double distCalc(int loc1, int loc2)
{
	double data;
	data = euDistance(row[loc1], col[loc1], row[loc2], col[loc2]);
	return data;
}
void initVisited()
{
	int i;
	for (i = 0; i < edge; i++)
	{
		visited[i] = 0;
	}
}