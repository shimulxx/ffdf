#include<stdio.h>
#define size 10
int data[size];
int visited[size];
int n;
int max;
void input();
void solveWork(int k);
void solve(int i, int sum);
int main()
{
	int k,t;
	freopen("BaloonInput.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork(k);
	}
}
void input()
{
	int i;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &data[i]);
		visited[i] = 0;
	}
}
void solveWork(int k)
{
	max = -999;
	solve(0, 0);
	printf("#%d %d\n",k, max);
}
void solve(int i, int sum)
{
	int j, k, left, right;
	left = 1;
	right = 1;
	if (i == n - 1)
	{
		if (sum > max)
			max = sum;
		return;
	}
	for (j = 0; j < n; j++)
	{
		if (!visited[j])
		{
			for (k = j - 1; k >= 0; k--)
			{
				if (!visited[k])
				{
					left = data[k];
					break;
				}
			}
			for (k = j + 1; k < n; k++)
			{
				if (!visited[k])
				{
					right = data[k];
					break;
				}
			}
			sum += left*right;
			visited[j] = 1;
			solve(i + 1, sum);
			visited[j] = 0;
			sum -= left*right;
			left = 1;
			right = 1;
		}
	}
}