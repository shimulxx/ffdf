// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include <stdio.h>


int main()
{
	printf("Hello");
    return 0;
}

