#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int mat[20][20];
int n;
int node;
int edge;
int visited[20];
int data[20];
void input();
void initMat();
void display();
void floidA();
void visitAndPrint();
void intVisited();
void initData();
int main()
{
	int k,t;
	freopen("p7.txt", "r", stdin);
	freopen("pop.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		scanf("%d %d", &node, &edge);
		initMat();
		intVisited();
		input();
		floidA();
		printf("#%d ", k);
		visitAndPrint();
	}
	
}
void input()
{
	int k, i, j;
	for (k = 1; k <= edge; k++)
	{
		scanf("%d %d", &i, &j);
		mat[i][j] = 1;
	}
}
void initMat()
{
	int i, j;
	for (i = 1; i <= node; i++)
	{
		for (j = 1; j <= node; j++)
		{
			if (i == j)
			{
				mat[i][j] = 1;
			}
			else
			{
				mat[i][j] = 0;
			}
		}
	}
}
void display()
{
	int i, j;
	for (i = 1; i <= node; i++)
	{
		for (j = 1; j <= node; j++)
		{
			printf("%d ", mat[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}
void floidA()
{
	int i, j, k;
	for (k = 1; k <= node; k++)
	{
		for (i = 1; i <= node; i++)
		{
			for (j = 1; j <= node; j++)
			{
				if (mat[i][k] == 1 && mat[k][j] == 1)
				{
					mat[i][j] = 1;
				}
			}
		}
	}
}
void visitAndPrint()
{
	int i, j, p, loc,k;
	for (i = 1; i <= node; i++)
	{
		p = 0;
		/*if (!visited[i])
		{
			printf("%d ", i);
			visited[i] = 1;
			p = 1;
		}*/
		initData();
		loc = 1;
		for (j = 1; j <= node; j++)
		{
			if (mat[i][j] == 1 && mat[j][i] == 1 && !visited[j])
			{
				visited[j] = 1;
				//printf("%d ", j);
				data[loc] = j;
				++loc;
				p = 1;
			}

		}
		if (data[1] != 0 && data[2] == 0)
		{
			continue;
		}
		else
		{
			for (k = 1; data[k] != 0; k++)
			{
				printf("%d ", data[k]);
			}
			break;
		}
	}
	if (i == node + 1)
	{
		printf("-1");
	}
	printf("\n");
}
void intVisited()
{
	int i;
	for (i = 1; i <= node; i++)
	{
		visited[i] = 0;
	}
}
void initData()
{
	int i;
	for (i = 1; i <= node; i++)
	{
		data[i] = 0;
	}
}