#include<stdio.h>

#define SIZE_ROW 100
#define SIZE_COL 100

int N;
char Grid[SIZE_ROW][SIZE_COL];

void readCase()
{
	N = 1;
	while (gets(Grid[N])) {
		if (Grid[N][0] == '_')
			break;
		N++;
	}
}

void solveCase()
{
}

void printCase()
{
	int i;
	for (i=0; i<=N; i++)
		puts(Grid[i]);
}

int main()
{
	freopen("input.txt", "r", stdin);
	while (gets(Grid[0])) {
		readCase();
		solveCase();
		printCase();
	}
	return 0;
}

/*

  XXXXXXXXXXXXXXXXXXXX
  X      X           X
  X # #  XXXXXXXX /  X
  X             X    X
  XXXXXXXXXXXXXXXXXXXX
_____________________________

   XXXXXXXXXXXX       XXXXXX
  X       #   XXX  XXX   X X
  X  XX         X  X     X X
 X  X  X  XXXXXXX  XXXXXXX
 X   XX   X
  X       X  XXXX  XXXXXXXX
   XX     XXXX  X  X  /   X
    X           X  X    / X
    XXXXXXXXXXXXX  XXXXXXXX
_____________________________

*/
