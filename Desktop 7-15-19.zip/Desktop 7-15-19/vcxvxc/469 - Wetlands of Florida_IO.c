#include<stdio.h>

#define SIZE 101

int T, N, M;
char Map[SIZE][SIZE];
int Used[SIZE][SIZE];
int Ans;

void readCase()
{
	N = 0;
	while (gets(Map[N])) {
		if (Map[N][0] != 'L' && Map[N][0] != 'W')
			break;
		N++;
	}
}

void solveCase()
{
	int i, x, y;
	while (Map[N][0] != '\0') {
		i = x = y = 0;
		while (Map[N][i] != ' ') {
			x = x*10 + Map[N][i] - '0';
			i++;
		}
		i++;
		while (Map[N][i] != '\0') {
			y = y*10 + Map[N][i] - '0';
			i++;
		}
		resetUsed();
		x--;
		y--;
		fill(x, y);
		printf("%d\n", Ans);
		if (!gets(Map[N]))
			break;
	}
	if (T)
		printf("\n");
}

int main()
{
	freopen("input.txt", "r", stdin);
	scanf("%d ", &T);
	while (T--) {
		readCase();
		solveCase();
	}
	return 0;
}
