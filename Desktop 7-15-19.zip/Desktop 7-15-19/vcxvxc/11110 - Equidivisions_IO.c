#include<stdio.h>

#define SIZE 101

int N;
int Grid[SIZE][SIZE];
int Count;
int Ans;

void initCase()
{
	int i, j;
	for (i=0; i<N; i++) for (j=0; j<N; j++)
		Grid[i][j] = N;
}

void readCase()
{
	int i, x, y;
	char ch;
	for (i=1; i<N; i++) while (1) {
		scanf("%d %d%c", &x, &y, &ch);
		Grid[x-1][y-1] = i;
		if (ch == '\n')
			break;
	}
}

void solveCase()
{
}

void printCase()
{
	if (!Ans)
		printf("wrong\n");
	else
		printf("good\n");
}

int main()
{
	freopen("input.txt", "r", stdin);
	while (1 == scanf("%d", &N) && N) {
		initCase();
		readCase();
		solveCase();
		printCase();
	}
	return 0;
}
