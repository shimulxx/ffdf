#include <stdio.h>

#define SIZE 101

int T;
int X, Y;
char Grid[SIZE][SIZE];
int N, M;
int used[SIZE][SIZE];
int Ans;

void readCase()
{
	int i;
	gets(Grid[0]);
	X = 0;
	for (i=0; Grid[0][i]!=' '; i++)
		X = X*10 + (Grid[0][i] - '0');
	X--;
	Y = 0;
	for (i++; Grid[0][i]; i++)
		Y = Y*10 + (Grid[0][i] - '0');
	Y--;
	N = 0;
	while (gets(Grid[N]) && Grid[N][0])
		N++;
}

void solveCase()
{
	Ans = 0;
}

void printCase()
{
	printf("%d\n", Ans);
	if (T)
		printf("\n");
}

int main()
{
	freopen("input.txt", "r", stdin);
	scanf("%d ", &T);
	while (T--) {
		readCase();
		solveCase();
		printCase();
	}
	return 0;
}
