#include<stdio.h>
#define size 205
int adMat[size][size];
int color[size];
int node, edge;
void input();
void initMat();
int solve(int i, int c); //fill
int solveWork();
void display();
int main()
{
	input();
	return 0;
}
void input()
{
	int k, i, j;
	while (1 == scanf("%d", &node) && node != 0)
	{
		initMat();
		scanf("%d", &edge);
		for (k = 1; k <= edge; k++)
		{
			scanf("%d %d", &i, &j);
			adMat[i][j] = 1;
			adMat[j][i] = 1;
		}
		display();
	}
}
void initMat()
{
	int i, j;
	for (i = 0; i < node; i++)
	{
		color[i] = 0;
		for (j = 0; j < node; j++)
		{
			adMat[i][j] = 0;
		}
	}
}
int solve(int i, int c)
{
	int j;
	if (color[i] == 0)
	{
		color[i] = c;
	}
	else if (color[i] == c)
	{
		return 1;
	}
	else
	{
		return 0;
	}
	for (j = 0; j < node; j++)
	{
		if (adMat[i][j] == 1 && 0 == solve(j, 3 - c))
		{
			return 0;
		}
	}
	return 1;
}
int solveWork()
{
	int i;
	for (i = 0; i < node; i++)
	{
		if (color[i] == 0 && 0 == solve(i, 1))
			return 0;
	}
	return 1;
}
void display()
{
	if (solveWork() == 1)
		printf("BICOLORABLE.\n");
	else
		printf("NOT BICOLORABLE.\n");
}