#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int node;
int edge;
int adMat[3][3];
int color[3];
void input();
void display();
void initAdMatColor();
int fill(int i, int c);
int solveWork();
int main()
{
	freopen("biColorInput.txt", "r", stdin);
	while (scanf("%d", &node) != EOF && node != 0)
	{
		initAdMatColor();
		input();
		display();
	}
	return 0;
}
void input()
{
	int i, j, k;
	scanf("%d", &edge);
	for (k = 1; k <= edge; k++)
	{
		scanf("%d %d", &i, &j);
		adMat[i][j] = 1;
		adMat[j][i] = 1;
	}
}
void initAdMatColor()
{
	int i, j;
	for (i = 0; i < node; i++)
	{
		for (j = 0; j < node; j++)
		{
			adMat[i][j] = 0;
		}
	}
	for (i = 0; i < node; i++)
	{
		color[i] = 0;
	}
}
void display()
{
	if (solveWork() == 1)
	{
		printf("BICOLORABLE.\n");
	}
	else
	{
		printf("NOT BICOLORABLE.\n");
	}
}
int fill(int i, int c)
{
	int j;
	if (color[i] == 0)
	{
		color[i] = c;
	}
	else if (color[i] == c)
	{
		return 1;
	}
	else
	{
		return 0;
	}
	for (j = 0; j < node; j++)
	{
		if (adMat[i][j] == 1 && 0 == fill(j, 3 - c))
		{
			return 0;
		}
	}
	return 1;
}
int solveWork()
{
	int i;
	for (i = 0; i < node; i++)
	{
		if (color[i] == 0 && 0 == fill(i, 1))
		{
			return 0;
		}
	}
	return 1;
}