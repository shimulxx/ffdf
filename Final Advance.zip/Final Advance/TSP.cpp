#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<math.h>
#define size 160
int edge;
int done;
int min;
int data[size];
int visited[size];
int sRval, sCval;
int dRval, dCval;
int row[size];
int col[size];
void input();
void solve(int i, int d);
void swapWork(int locF, int locD);
int manDistance(int x1, int y1, int x2, int y2);
int distCalc(int loc1, int loc2);
void solveWork();
void initVisited();
int absW(int a);
int main()
{
	int k, t;
	freopen("tspInput.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork();
	}
	return 0;
}
void solve(int i, int d)
{
	int j;
	int sum;
	if (i == edge)
	{
		sum = manDistance(sRval, sCval, row[data[0]], col[data[0]]) + manDistance(dRval, dCval, row[data[edge - 1]], col[data[edge - 1]]);
		for (j = 0; j < edge - 1 ; j++)
		{
			sum += distCalc(data[j], data[j + 1]);
		}
		if (sum < min)
		{
			min = sum;
		}
		return;
	}
	for (j = 0; j < edge; j++)
	{
		if (!visited[j])
		{
			data[i] = j;
			visited[j] = 1;
			solve(i + 1, d);
			visited[j] = 0;
		}
	}
}
void input()
{
	int i;
	scanf("%d", &edge);
	scanf("%d %d %d %d", &sRval, &sCval, &dRval, &dCval);
	for (i = 0; i < edge; i++)
	{
		scanf("%d %d", &row[i], &col[i]);
	}
}
int manDistance(int x1, int y1, int x2, int y2)
{
	int data;
	data = absW(x1 - x2) + abs(y1 - y2);
	return data;
}
void swapWork(int locF, int locD)
{
	int tmpR, tmpC;
	tmpR = row[locF];
	tmpC = col[locF];
	row[locF] = row[locD];
	col[locF] = col[locD];
	row[locD] = tmpR;
	col[locD] = tmpC;
}
void solveWork()
{
	int i;
	done = 0;
	min = 999999;
	solve(0, 0);
	printf("%d\n", min);
}
int distCalc(int loc1, int loc2)
{
	int data;
	data = manDistance(row[loc1], col[loc1], row[loc2], col[loc2]);
	return data;
}
void initVisited()
{
	int i;
	for (i = 0; i < edge; i++)
	{
		visited[i] = 0;
	}
}
int absW(int a)
{
	if (a < 0)
		return -a;
	return a;
}