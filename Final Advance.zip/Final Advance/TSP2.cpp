#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<math.h>
#define size 30
int edge;
int done;
int min;
int data[size];
int visited[size];
int sRowVal, sColVal;
int dRowVal, dColVal;
int row[size];
int col[size];
int mrow[size];
int mcol[size];
void input();
void solve(int i, int d);
void swapWork(int locF, int locD);
int manDistance(int x1, int y1, int x2, int y2);
int distCalc(int loc1, int loc2);
int absW(int a);
void solveWork();
void initVisited();
int main()
{
	int k, t;
	freopen("tspInput.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork();
	}
	return 0;
}
void solve(int i, int d)
{
	int j, sum;
	sum = 0;
	if (i == edge)
	{
		for (j = 0; j < edge - 1; j++)
		{
			sum += distCalc(data[j], data[j + 1]);
		}
		//printf("%d\n", sum);
		sum += manDistance(sRowVal, sColVal, data[0], data[0]) + manDistance(data[j], data[j], dRowVal, dColVal);
		if (sum < min)
		{
			min = sum;
			printf("%d\n", sum);
		}
		return;
	}
	for (j = 0; j < edge; j++)
	{
		if (!visited[j])
		{
			data[i] = j;
			visited[j] = 1;
			solve(i + 1, d);
			visited[j] = 0;
		}
	}
}
void input()
{
	int i;
	scanf("%d", &edge);
	scanf("%d %d", &sRowVal, &sColVal);
	scanf("%d %d", &dRowVal, &dColVal);
	for (i = 0; i < edge; i++)
	{
		scanf("%d %d", &row[i], &col[i]);
	}
	/*row[0] = sRowVal;
	col[0] = sColVal;
	row[i] = dRowVal;
	col[i] = dColVal;
	edge += 2;*/
}
int manDistance(int x1, int y1, int x2, int y2)
{
	int data;
	data = absW(x1 - x2) + absW(y1 - y2);
	return data;
}
void swapWork(int locF, int locD)
{
	int tmpR, tmpC;
	tmpR = row[locF];
	tmpC = col[locF];
	row[locF] = row[locD];
	col[locF] = col[locD];
	row[locD] = tmpR;
	col[locD] = tmpC;
}
void solveWork()
{
	int i;
	done = 0;
	min = 999999;
	for (i = 0; i < edge ; i++)
	{
		swapWork(0, i);
		initVisited();
		solve(0, 0);
		swapWork(i, 0);
	}
	printf("%d\n", min);
}
int distCalc(int loc1, int loc2)
{
	int data;
	data = manDistance(row[loc1], col[loc1], row[loc2], col[loc2]);
	return data;
}
void initVisited()
{
	int i;
	for (i = 0; i < edge; i++)
	{
		visited[i] = 0;
	}
}
int absW(int a)
{
	if (a < 0)
		return -a;
	return a;
}