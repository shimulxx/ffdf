#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int a[20];
int visited[20];
int row[20];
int col[20];
int n;
int s = 1;
int str;
int stc;
int t;
int minCount;
int hx, hy;
int ox, oy;
void solve(int i);
int absV(int a);
void input();
int manDistance(int x1, int y1, int x2, int y2);
void visitInt();
void solveRun();
void printWork(int a);
int main()
{
	freopen("tspInput.txt", "r", stdin);
	//freopen("tspOutput.txt", "w", stdout);
	while (1 == scanf("%d", &t))
	{
		if (t == 0)
			break;
		input();
	}
	return 0;
}
void work()
{
	int i, sum = 0, x = 0;
	sum = manDistance(hx, hy, row[a[0]], col[a[0]]) + manDistance(ox, oy, row[a[n - 1]], col[a[n - 1]]);
	printf("%d\n", sum);
	for (i = 0; i < n - 1; i++)
	{
		sum += manDistance(row[a[i]], col[a[i]], row[a[i + 1]], col[a[i + 1]]);
	}
	printf("%d\n",sum);
	if (sum < minCount)
		minCount = sum;

}
void solve(int i)
{
	int j;
	if (i == n)
	{
		work();
		return;
	}
	for (j = 0; j < n; j++)
	{
		if (0 == visited[j])
		{
			a[i] = j;
			visited[j] = 1;
			solve(i + 1);
			visited[j] = 0;
		}
	}
}
int absV(int a)
{
	if (a < 0)
		return -a;
	return a;
}
void input()
{
	int i, r, c, x;
	for (x = 1; x <= t; x++)
	{
		scanf("%d", &n);
		scanf("%d %d", &hx, &hy);
		scanf("%d %d", &ox, &oy);
		for (i = 0; i < n; i++)
		{
			scanf("%d %d", &row[i], &col[i]);
		}
		solveRun();
		//printWork(x);
	}

}
int manDistance(int x1, int y1, int x2, int y2)
{
	return absV(x1 - x2) + absV(y1 - y2);
}
void visitInt()
{
	int i;
	for (i = 0; i < n; i++)
	{
		visited[i] = 0;
	}
}
void solveRun()
{
	minCount = 999999;
	visitInt();
	solve(0);
}
void printWork(int a)
{
	printf("#%d %d\n", a, minCount);
}