#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

int N, T;
int visited[21];
int x[21], y[21];
int min;

int ABs(int n){
	if (n < 0) return -n;
	else return n;
}

void initVisited(){
	int i;
	for (i = 1; i <= N; i++)
		visited[i] = 0;
}

void solve(int source, int customers, int dist){

	if (customers == N){
		dist += ABs(x[source] - x[N + 1]) + ABs(y[source] - y[N + 1]);
		if (dist < min)
			min = dist;
		return;
	}
	int j;

	for (j = 1; j <= N; j++)if (!visited[j]){
		visited[j] = 1;
		solve(j, customers + 1, dist + ABs(x[source] - x[customers]) + ABs(y[source] - y[customers]));
		visited[j] = 0;
	}
}

void solveCase(){
	initVisited();
	solve(0, 0, 0);
}

void readCase(){

	scanf("%d", &N);
	scanf("%d %d", &x[0], &y[0]);
	scanf("%d %d", &x[N + 1], &y[N + 1]);
	int i;
	for (i = 1; i <= N; i++){
		scanf("%d %d", &x[i], &y[i]);
	}
}

void printCase(){
	printf("%d\n", min);
}
int main(){
	int i;
	freopen("mock1_in.txt", "r", stdin);
	freopen("mock1_out.txt", "w", stdout);
	scanf("%d", &T);
	for (i = 1; i <= T; i++){
		min = 1000000;
		readCase();
		initVisited();
		solveCase();
		printf("#%d ", i);
		printCase();
	}
	return 0;
}