#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int row;
int col;
int srow;
int scol;
int count;
char grid[10][10];
void input();
void display();
void startFind();
void solve(int i, int j);
void solveWork();
void display2();
int main()
{
	freopen("p7.txt", "r", stdin);
	while (2 == scanf("%d %d", &col, &row))
	{
		input();
		startFind();
		solveWork();
		display();

	}
	return 0;
	
}
void input()
{
	int i;
	for (i = 0; i < row; i++)
	{
		scanf("%s", grid[i]);
	}
}
void display()
{
	printf("%d\n", count);
}
void startFind()
{
	int i, j , p;
	p = 0;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			if (grid[i][j] == 'P')
			{
				p = 1;
				srow = i;
				scol = j;
				break;
			}
			if (p == 1)
			{
				break;
			}
		}
	}
}
void solve(int i, int j)
{
	grid[i][j] = 'X';
	display2();
	//i j+1-----right
	if (j + 1 < col)
	{
		if ('T' == grid[i][j + 1])
		{
			return;
		}
		if ('.' == grid[i][j + 1])
		{
			solve(i, j + 1);
		}
		if ('G' == grid[i][j + 1])
		{
			++count;
			solve(i, j + 1);
		}
	}
	//i j-1----left
	if (j - 1 >= 0)
	{
		if ('T' == grid[i][j - 1])
		{
			return;
		}
		if ('.' == grid[i][j - 1])
		{
			solve(i, j - 1);
		}
		if ('G' == grid[i][j - 1])
		{
			++count;
			solve(i, j - 1);
		}
	}
	//i+1 j-------down
	if (i + 1 < row)
	{
		if ('T' == grid[i + 1][j])
		{
			return;
		}
		if ('.' == grid[i + 1][j])
		{
			solve(i + 1, j);
		}
		if ('G' == grid[i + 1][j])
		{
			++count;
			solve(i + 1, j);
		}
	}
	//i-1 j----up
	if (i - 1 >= 0)
	{
		if ('T' == grid[i - 1][j])
		{
			return;
		}
		if ('.' == grid[i - 1][j])
		{
			solve(i - 1, j);
		}
		if ('G' == grid[i - 1][j])
		{
			++count;
			solve(i - 1, j);
		}
	}
}
void solveWork()
{
	count = 0;
	solve(srow, scol);
}
void display2()
{
	int i, j;
	for (i = 0; i < row; i++)
	{
		printf("%s\n", grid[i]);
	}
	printf("\n");
}