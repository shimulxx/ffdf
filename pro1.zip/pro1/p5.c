#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int n;
int a[3];
int sum;
void input()
{
	int i;
	sum = 0;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		sum += a[i];
	}
	sum = sum / 2;
}
int solve(int i, int sub)
{
	int left, right;
	printf("%d %d\n", i, sub);
	if (i == n)
	{
		return sub;
	}
	if (a[i] <= sub)
		right = a[i]+solve(i + 1, sub - a[i]);
	else
		right = 0;
	left = solve(i + 1, sub);
	if (left < right)
		return left;
	else
		return right;
}
int main()
{
	input();
	printf("%d", solve(0, sum));
}