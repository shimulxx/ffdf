#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int node;
int edge;
int adMat[301][301];
int color[301];
void input();
void display();
void initAdMatColor();
int fill(int i, int c);
int solveWork();
int main()
{

	while (scanf("%d", &node) != EOF && node != 0)
	{
		initAdMatColor();
		input();
		display();
	}
	return 0;
}
void input()
{
	int i, j, k;
	while (2 == scanf("%d %d", &i, &j) && i != 0 && j != 0)
	{
		adMat[i][j] = 1;
		adMat[j][i] = 1;
	}
}
void initAdMatColor()
{
	int i, j;
	for (i = 0; i < node; i++)
	{
		for (j = 0; j < node; j++)
		{
			adMat[i][j] = 0;
		}
	}
	for (i = 0; i < node; i++)
	{
		color[i] = 0;
	}
}
void display()
{
	if (solveWork() == 1)
	{
		printf("YES\n");
	}
	else
	{
		printf("NO\n");
	}
}
int fill(int i, int c)
{
	int j;
	if (color[i] == 0)
	{
		color[i] = c;
	}
	else if (color[i] == c)
	{
		return 1;
	}
	else
	{
		return 0;
	}
	for (j = 0; j < node; j++)
	{
		if (adMat[i][j] == 1 && 0 == fill(j, 3 - c))
		{
			return 0;
		}
	}
	return 1;
}
int solveWork()
{
	int i;
	for (i = 0; i < node; i++)
	{
		if (color[i] == 0 && 0 == fill(i, 1))
		{
			return 0;
		}
	}
	return 1;
}