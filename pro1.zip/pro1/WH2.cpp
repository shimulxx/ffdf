#define _CRT_SECURE_NO_WARNINGS
//complete
#include<stdio.h>
int M, N, W, X[11], Y[11], U[6], V[6], cost[6], Ans, visited[11], Case;
int absdif(int a, int b)
{
	if (a >= b)
		return a - b;
	else return b - a;

}
void printcase()
{
	printf("#%d %d\n", Case, Ans);
}
void solve(int r, int c, int dist)
{
	int i, distu, distv;
	if (N - r + N - c + dist < Ans)
	{
		Ans = N - r + N - c + dist;
		/*printf("%d",Ans);
		for(i=1;i<=W;i++)
		{
		printf("%d",visited[i]);
		}
		printf("\n");
		*/
	}
	if (dist > Ans)
		return;
	for (i = 1; i <= W; i++)
	{
		if (0 == visited[i])
		{
			visited[i] = 1;
			distu = absdif(r, X[U[i]]) + absdif(c, Y[U[i]]);
			distv = absdif(r, X[V[i]]) + absdif(c, Y[V[i]]);
			if (distu < distv)
			{
				solve(X[V[i]], Y[V[i]], dist + distu + cost[i]);
			}
			else
				solve(X[U[i]], Y[U[i]], dist + distv + cost[i]);

			visited[i] = 0;
		}
	}
}
void solvecase()
{
	int i;
	Ans = (N - 1) * 2;
	for (i = 1; i <= W; i++)
		visited[i] = 0;
	solve(1, 1, 0);

}
void readcase()
{
	int i, x, y, s, d;
	scanf("%d %d %d", &N, &M, &W);
	for (i = 1; i <= M; i++)
	{
		scanf("%d %d", &X[i], &Y[i]);

	}
	for (i = 1; i <= W; i++)
	{
		scanf("%d %d %d", &U[i], &V[i], &cost[i]);
	}

}
int main()
{
	int t, i;
	freopen("p7.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	scanf("%d", &t);
	for (i = 0; i < t; i++)
	{
		readcase();
		solvecase();
		Case++;
		printcase();
	}

}
