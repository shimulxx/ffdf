#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void work(int a[2][2]);
int main()
{
	int a[2][2] = { 1, 2, 3, 4 };
	int i,j;
	for (i = 0; i < 2; i++)
	{
		for (j = 0; j < 2; j++)
		{
			printf("%d ", a[i][j]);
		}
	}
	work(a);
}
void work(int a[2][2])
{
	printf("%d", a[0][0]);
}