#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int row;
int col;
char mat[100][101];
int count;
void solve(int x, int y);
void input();
void display();
void solveCase();
int main()
{
	freopen("p7.txt", "r", stdin);
	while (2 == scanf("%d %d", &row, &col) && row != 0)
	{
		input();
		solveCase();
		display();
	}
	return 0;
}
void input()
{
	int i;
	for (i = 0; i < row; i++)
	{
		scanf("%s", mat[i]);
	}
}
void display()
{
	printf("%d\n",count);
}
void solveCase()
{
	int i, j;
	count = 0;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			if ('@' == mat[i][j])
			{
				count++;
				solve(i, j);
			}
		}
	}
}
void solve(int x, int y)
{
	mat[x][y] = '*';
	if (x - 1 >= 0 && y - 1 >= 0 && '@' == mat[x - 1][y - 1])
		solve(x - 1, y - 1);
	if (x - 1 >= 0  && '@' == mat[x-1][y])
		solve(x-1, y);
	if (x - 1 >= 0 && y + 1 < col && '@' == mat[x - 1][y + 1])
		solve(x - 1, y + 1);
	if (y - 1 >= 0 && '@' == mat[x][y - 1])
		solve(x, y - 1);
	if (y + 1 < col && '@' == mat[x][y + 1])
		solve(x, y + 1);
	if (x + 1 < row && y - 1 >= 0 && '@' == mat[x + 1][y - 1])
		solve(x + 1, y - 1);
	if (x + 1 < row  && '@' == mat[x + 1][y])
		solve(x + 1, y);
	if (x + 1 < row  && y + 1 < col &&'@' == mat[x + 1][y + 1])
		solve(x + 1, y + 1);
}