#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#define size 4
int visited[size];
int a[size];
int n;
void init();
void solve(int i);
int main()
{
	init();
	scanf("%d", &n);
	solve(0);
}
void init()
{
	int i;
	for (i = 0; i < n; i++)
	{
		visited[i] = 0;
	}
}
void solve(int i)
{
	int j;
	if (i == n)
	{
		for (j = 0; j < n; j++)
		{
			printf("%d",a[j]);
		}
		printf("\n");
		return;
	}
	for (j = 1; j <= n; j++)
	{
		if (!visited[j])
		{
			visited[j] = 1;
			a[i] = j;
			solve(i + 1);
			visited[j] = 0;
		}
	}
}