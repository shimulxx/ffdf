#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int n;
int a[8];
int visited[10];
int chess[8][8];
int count;
void input();
void solve(int i);
void display();
void initVisited();
void chessInt();
int queenWork(int i, int j);
void combCount();
void solveRun();
void prin();
void failed();
int main()
{
	int i;
	freopen("p7.txt", "w", stdout);
	n = 8;
	solveRun();
	/*for (i = 0; i < n; i++)
	{
		printf("%d", queenWork(i, a[i]));
	}*/
	printf("%d", count);
}
void solve(int i)
{
	int j;
	if (i == n)
	{
		combCount();
		return;
	}
	for (j = 0; j < n; j++)
	{
		if (0 == visited[j])
		{
			a[i] = j;
			visited[j] = 1;
			solve(i + 1);
			visited[j] = 0;
		}
	}
	return;
}
void initVisited()
{
	int i;
	for (i = 0; i < n; i++)
	{
		visited[i] = 0;
	}
}
void display()
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			printf("%d ", chess[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}
void input()
{
	scanf("%d", &n);
}
void chessInt()
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			chess[i][j] = 0;
		}
	}
}
void failed()
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			chess[i][j] = 1;
		}
	}
}
int queenWork(int i, int j)
{
	int r, c;
	if (chess[i][j] == 1)
	{
		failed();
		return 0;
	}
	r = i;
	c = j;
	while (r+1 != n)
	{
		chess[r+1][c] = 1;
		++r;
	}
	r = i;
	c = j;
	while (c+1 != n)
	{
		chess[r][c+1] = 1;
		++c;
	}
	r = i;
	c = j;
	while (r-1 != -1)
	{
		chess[r-1][c] = 1;
		--r;
	}
	r = i;
	c = j;
	while (c-1 != -1)
	{
		chess[r][c-1] = 1;
		--c;
	}
	r = i;
	c = j;
	while (r+1 != n && c+1 != n)
	{
		chess[r+1][c+1] = 1;
		++r;
		++c;
	}
	r = i;
	c = j;
	while (r-1 != -1 && c-1 != -1)
	{
		chess[r-1][c-1] = 1;
		--r;
		--c;
	}
	r = i;
	c = j;
	while (r+1 != n && c-1 != -1)
	{
		chess[r+1][c-1] = 1;
		++r;
		--c;
	}
	r = i;
	c = j;
	while (r-1 != -1 && c+1 != n)
	{
		chess[r-1][c+1] = 1;
		--r;
		++c;
	}
	chess[i][j] = 1;
	if (i == n - 1)
		return 1;
	else
		return 0;
}
void combCount()
{
	int i;
	//count = 0;
	for (i = 0; i < n; i++)
	{
		if (1 == queenWork(i, a[i]))
		{
			++count;
			prin();
		}
			
	}
	chessInt();
}
void solveRun()
{
	count = 0;
	initVisited();
	solve(0);
}
void prin()
{
	int i;
	for (i = 0; i < n; i++)
	{
		printf("%d, ", a[i]);
	}
	printf("\n");
}
