#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#define size 32
int adMat[size][size];
int nodeArray[size];
int level[size];
int queue[size];
int visited[size];
int pair;
int totalNode;
int notReachable;
int totalVisit;
int k;
void input();
void solveWork();
int searchArray(int data);
void arrayInsert(int data);
void upDateAd(int d1, int d2);
void calcTotalNode();
void queueOperation(int startNode, int depth);
void display(int node, int ttl);
void initVisited();
void initMat();
void initQueue();
void initNodeArray();
int main()
{
	k = 1;
	freopen("p7.txt", "r", stdin);
	freopen("pop.txt", "w", stdout);
	while (1 == scanf("%d", &pair) && pair != 0)
	{
		initMat();
		initNodeArray();
		input();
		solveWork();
	}
	return 0;
}
void input()
{
	int k, d1, d2;
	for (k = 1; k <= pair; k++)
	{
		scanf("%d %d", &d1, &d2);
		upDateAd(d1, d2);
	}
	calcTotalNode();
}
void upDateAd(int d1, int d2)
{
	int p1, p2;
	if (searchArray(d1) == -1)
	{
		arrayInsert(d1);
	}
	p1 = searchArray(d1);
	if (searchArray(d2) == -1)
	{
		arrayInsert(d2);
	}
	p2 = searchArray(d2);
	adMat[p1][p2] = 1;
	adMat[p2][p1] = 1;
}
void solveWork()
{
	int d1, d2;
	while (2 == scanf("%d %d", &d1, &d2) && (d1 != 0 || d2 != 0))
	{
		initVisited();
		initQueue();
		queueOperation(d1, d2);
		display(d1, d2);
		++k;
	}
}
int searchArray(int data)
{
	int i;
	for (i = 0; nodeArray[i] != -1; i++)
	{
		if (data == nodeArray[i])
			return i;
	}
	return -1;
}
void arrayInsert(int data)
{
	int i;
	for (i = 0; i < size; i++)
	{
		if (nodeArray[i] == -1)
		{
			nodeArray[i] = data;
			return;
		}
	}
}
void calcTotalNode()
{
	int i;
	for (i = 0; nodeArray[i] != -1; i++);
	totalNode = i;
}
void queueOperation(int startNode, int depth)
{
	int i;
	int left, right;
	level[0] = 0;
	queue[0] = searchArray(startNode);
	visited[queue[0]] = 1;
	left = 0;
	right = 1;
	if (queue[0] == -1)
	{
		notReachable = totalNode;
		return;
	}
	while (left != right)
	{
		if (level[left] == depth)
		{
			notReachable = totalNode - right;
			return;
		}
		for (i = 0; i < totalNode; i++)
		{
			if (adMat[queue[left]][i] != 0 && !visited[i])
			{
				queue[right] = i;
				level[right] = level[left] + 1;
				visited[i] = 1;
				++right;
			}
		}
		++left;
	}
	notReachable = totalNode - right;
}
void display(int node, int ttl)
{
	printf("Case %d: %d nodes not reachable from node %d with TTL = %d.\n", k, notReachable, node, ttl);
}
void initVisited()
{
	int i;
	for (i = 0; i < totalNode; i++)
	{
		visited[i] = 0;
	}
}
void initMat()
{
	int i, j;
	for (i = 0; i < size; i++)
	{
		queue[i] = 0;
		for (j = 0; j < size; j++)
		{
			adMat[i][j] = 0;
		}
	}
}
void initQueue()
{
	int i;
	for (i = 0; i < size; i++)
	{
		queue[i] = 0;
	}
}
void initNodeArray()
{
	int i;
	for (i = 0; i < size; i++)
	{
		nodeArray[i] = -1;
	}
}