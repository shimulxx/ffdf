#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int node;
int edge;
int isFirst;
int adMat[101][101];
int visited[101];
int inDeg[101];
void input();
void display();
void display2();
void intAdmatVis();
void solve();
int main()
{
	freopen("p7.txt", "r", stdin);
	while (scanf("%d %d", &node, &edge) != EOF && node != 0 && edge != 0)
	{
		isFirst = 1;
		intAdmatVis();
		input();
		solve();
		//display2();
		printf("\n");
	}

}
void input()
{
	int i, j, k;
	for (k = 1; k <= edge; k++)
	{
		scanf("%d %d", &i, &j);
		adMat[i][j] = 1;
		++inDeg[j];
	}

}
void display()
{
	int i;
	for (i = 1; i <= node; i++)
	{
		if (!visited[i] && inDeg[i] == 0)
		{
			if (isFirst == 1)
			{
				printf("%d", i);
				isFirst = 0;
			}
			else
			{
				printf(" %d", i);
			}
			visited[i] = 1;
		}
	}
}
void intAdmatVis()
{
	int i, j;
	for (i = 1; i <= node; i++)
	{
		for (j = 1; j <= node; j++)
		{
			adMat[i][j] = 0;
		}
	}
	for (i = 1; i <= node; i++)
	{
		visited[i] = 0;
		inDeg[i] = 0;
	}
}
void solve()
{
	int i, j;
	for (i = 1; i <= node; i++)
	{
		
		for (j = 1; j <= node; j++)
		{
			
			if (adMat[i][j] == 1)
			{
				--inDeg[j];
				display();
			}
		}
		
	}
}
void display2()
{
	int i;
	for (i = 1; i <= node; i++)
		printf("%d ", inDeg[i]);
	printf("\n");
}