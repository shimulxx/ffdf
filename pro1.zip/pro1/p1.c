#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int m, n;
int coin[101];
int cases;
int total;
int ans;
int dp[101][50001];
void input()
{
	int i,j;
	for (i = 0; i < 101; i++)
	{
		for (j = 0; j < 50001; j++)
		{
			dp[i][j] = -1;
		}
	}
	total = 0;
	scanf("%d", &m);
	for (i = 0; i < m; i++)
	{scanf("%d", &coin[i]);
		total += coin[i];
	}
	ans = total;
}
int minx(int a, int b)
{
	if (a <= b)
		return a;
	return b;
}
int negwork(int a)
{
	if (a < 0)
		return -a;
	return a;
}
int solve(int i, int sum1)
{
	int sum2, dif,left,right;
	if (dp[i][sum1] != -1)
		return dp[i][sum1];
	if (i == m)
	{
		sum2 = total - sum1;
		dif = negwork(sum1 - sum2);
		return dif;
	}
	left=solve(i + 1, sum1);
	right=solve(i + 1, sum1 + coin[i]);
	return dp[i][sum1] = minx(left, right);
}
void display()
{
	printf("%d\n", ans);
}

int main()
{
	freopen("input.txt", "r", stdin);
	scanf("%d", &n);
	for (cases = 1; cases <= n; cases++)
	{
		input();
		printf("%d\n",solve(0, 0));
	}
}
