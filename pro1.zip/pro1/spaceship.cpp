#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int mat[8][6];
int visit2[10];
int visit3[10];
int visit4[10];
int n;
void input();
int visit(int i, int j);
void solveWork();
void initVisit();
int main()
{
	int k, t;
	freopen("p7.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		initVisit();
		solveWork();
	}
}
void input()
{
	int i, j;
	scanf("%d", &n);
	for (i = 1; i <= n; i++)
	{
		for (j = 1; j <= 5; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
}
int visit(int i, int j)
{
	if (mat[i][j] == 2)
		return 0;
	return 1;
}
void solveWork()
{
	int i,j;
	j = 1;
	for (i = n; i >= 1; i--)
	{
		//printf("%d %d %d\n", visit(i, 2), visit(i, 3),visit(i, 4));
		visit2[j] = visit(i, 2);
		visit3[j] = visit(i, 3);
		visit4[j] = visit(i, 4);
		++j;
	}	
}
void initVisit()
{
	int i;
	for (i = 1; i <= n; i++)
	{
		visit2[i] = 0;
		visit3[i] = 0;
		visit4[i] = 0;
	}
}