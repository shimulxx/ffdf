#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
// X = A*N + B*log(N) + C*N*N*N
// Input A B C X
// Output N
// 1 <= A <= 100
// 1 <= B <= 100
// 0 <= C <= 100
// 0 <= X <= 10^15
// N must be integer
// 0 <= N <= 10^13
long long int A;
long long int B;
long long int C;
long long int X;
long long int N;
long long int left;
long long int right;
long long int mid;
int log(long long n);
long long int binarySearch();
void input();
void display(int k);
int main()
{
	int k, t;
	freopen("p7.txt", "r", stdin);
	freopen("pop.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		display(k);
	}
}
int log(long long n)
{
	double d = (double)n;
	int value = 0;
	while (d >= 2.71828) {
		d /= 2.71828;
		value++;
	}
	return value;
}
void input()
{
	scanf("%lld %lld %lld %lld", &A, &B, &C, &X);
}
long long int binarySearch()
{
	long long int Y;
	if (C == 0)
	{
		left = 0;
		right = 10000000000000;
		mid = (left + right) / 2;
	}
	else
	{
		left = 0;
		right = 100000;
		mid = (left + right) / 2;
	}
	N = mid;
	Y = A*N + B*log(N) + C*N*N*N;
	while (X != Y)
	{
		if (X > Y)
		{
			left = mid + 1;
			mid = (left + right) / 2;
			N = mid;
			Y = A*N + B*log(N) + C*N*N*N;
		}
		if (X < Y)
		{
			right = mid - 1;
			mid = (left + right) / 2;
			N = mid;
			Y = A*N + B*log(N) + C*N*N*N;
		}
	}
	return N;
}
void display(int k)
{
	printf("#%d %lld\n",k, binarySearch());
}
