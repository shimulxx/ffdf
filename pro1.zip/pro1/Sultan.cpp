#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int n;
int mat[6][6];
int mat2[6][6];
void input();
void display();
void matMul();
int main()
{
	input();
	display();
}
void input()
{
	int i,j;
	scanf("%d", &n);
	for (i = 1; i <= n; i++)
	{
		for (j = 1; j <= n; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	printf("\n");
}
void display()
{
	int i, j;
	for (i = 1; i <= n; i++)
	{
		for (j = 1; j <= n; j++)
		{
			printf("%d ", mat[i][j]);
		}
		printf("\n");
	}
}
void matMul()
{
	int i, j ,sum=0;
	for (i = 1; i <= n; i++)
	{
		for (j = 1; j <= n; j++)
		{

		}
	}
}