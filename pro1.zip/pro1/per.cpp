#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int a[100];
int n;
void print()
{
	int i,j,p=0;
	for (i = 0; i < n; i++)
	{
		for (j = i + 1; j < n; j++)
		{
			if (a[i] == a[j])
			{
				p = 1;
				break;
			}
		}
	}
		if (p == 0)
		{
			for (i = 0; i < n; i++)
			{
				printf("%d", a[i]);
			}
			printf("\n");
		}	
}
void solve(int i)
{
	int j;
	if (i == n)
	{
		print();
		return;
	}
	/*a[i] = 0;
	solve(i + 1);
	a[i]= 1;
	solve(i + 1);*/
	for (j = 0; j < 3; j++)
	{
		a[i] = j;
		solve(i + 1);
	}
}
int main()
{
	scanf("%d", &n);
	//n = 3;
	//print();
	solve(0);
	return 0;
}