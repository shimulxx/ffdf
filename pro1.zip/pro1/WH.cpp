#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#define size 5
int visited[size];
int mrowData[size];
int mcolData[size];
int wrowData[size];
int wcolData[size];
int wValData[size];
int n;
int m;
int w;
int ans;
void intVisited();
void input();
void solve(int p, int i, int j, int dis);
int pointCheck(int i);
void display(int k);
int absV(int a);
int manDistance(int x1, int y1, int x2, int y2);
int minx(int a, int b);
int minimumDistance(int k);
int main()
{
	int k, t;
	freopen("p7.txt", "r", stdin);
	scanf("%d", &t);
   	for (k = 1; k <= t; k++)
	{
		input();
		intVisited();
		solve(1, 1, 1, 0);
		display(k);
	}
}
void input()
{
	int k;
	scanf("%d %d %d", &n, &m, &w);
	for (k = 1; k <= m; k++)
	{
		scanf("%d %d", &mrowData[k], &mcolData[k]);
	}
	for (k = 1; k <= w; k++)
	{
		scanf("%d %d %d", &wrowData[k], &wcolData[k], &wValData[k]);
	}
	ans = 2 * (n - 1);
}
void solve(int p, int i, int j, int dis)
{
	int k, dis1, dis2, minDis,t;
	if (dis > ans)
	{
		return;
	}
	if (p == w + 1)
	{
		dis += manDistance(i, j, n, n);
		if (dis < ans)
		{
			ans = dis;
		}
		return;
	}
	for (k = 1; k <= w; k++)
	{
		if (!visited[k])
		{
			visited[k] = 1;
			if (pointCheck(k) == 1)
			{
				continue;
			}
			else
			{
				minDis = minimumDistance(k);
				dis1 = manDistance(i, j, mrowData[wrowData[k]], mcolData[wrowData[k]]);
				dis2 = manDistance(i, j, mrowData[wcolData[k]], mcolData[wcolData[k]]);
				printf("%d\n", minDis);
				printf("%d %d %d %d\n", i, j, mrowData[wrowData[k]], mcolData[wrowData[k]]);
				printf("%d %d %d %d\n", i, j, mrowData[wcolData[k]], mcolData[wcolData[k]]);
				printf("dis1 = %d dis2 = %d\n", dis1,dis2);
				if (dis1 < dis2)
				{
					t = dis1 + minDis;
					printf("total = %d\n", t);
					solve(p + 1, mrowData[wcolData[k]], mcolData[wcolData[k]], dis1 + minDis);
				}
				else
				{
					solve(p + 1, mrowData[wrowData[k]], mcolData[wrowData[k]], dis2 + minDis);
				}
			}
			visited[k] = 0;
		}
	}
}
void display(int k)
{
	printf("#%d %d\n",k,ans);
}
int pointCheck(int i)
{
	if (wrowData[i] == wcolData[i])
	{
		return 1;
	}
	return 0;
}
void intVisited()
{
	int i;
	for (i = 1; i <= w; i++)
	{
		visited[i] = 0;
	}
}
int absV(int a)
{
	if (a < 0)
		return -a;
	return a;
}
int manDistance(int x1, int y1, int x2, int y2)
{
	return absV(x1 - x2) + absV(y1 - y2);
}
int minx(int a, int b)
{
	if (a <= b)
		return a;
	return b;
}
int minimumDistance(int k)
{
	int directDis;
	directDis = manDistance(mrowData[wrowData[k]], mcolData[wrowData[k]], mrowData[wcolData[k]], mcolData[wcolData[k]]);
	return minx(directDis, wValData[k]);
}