#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int n;
int data[10];
int visited[10];
int maxV;
void input();
void intVisit();
void solve(int i,int sum);
void display(int x);
void input();
void display2();
int main()
{
	int k,t;
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		maxV = -999;
		intVisit();
		input();
		solve(0, 0);
		display(k);
	}
	return 0;
}
void intVisit()
{
	int i;
	for (i = 0; i < n; i++)
	{
		visited[i] = 0;
	}
}
void solve(int i,int sum)
{
	int j,k;
	int left = 1;
	int right = 1;
	if (i == n - 1)
	{
		if (sum > maxV)
		{
			maxV = sum;
		}
		return;
	}
	for (j = 0; j < n; j++)
	{
		if (0 == visited[j])
		{
			for (k = j - 1; k >= 0; k--)
			{
				if (visited[k] == 0)
				{
					left = data[k];
					break;
				}
					
			}
			for (k = j + 1; k < n; k++)
			{
				if (visited[k] == 0)
				{
					right = data[k];
					break;
				}
			}
			sum += left*right;
			visited[j] = 1;
			solve(i + 1,sum);
			visited[j] = 0;
			sum -= left*right;
			left = 1;
			right = 1;
		}
	}
}
void display(int x)
{
	printf("#%d %d\n", x, maxV);
}
void input()
{
	int j;
	scanf("%d", &n);
	for (j = 0; j < n; j++)
	{
		scanf("%d", &data[j]);
	}

}
void display2()
{
	int i;
	for (i = 0; i < n; i++)
	{
		printf("%d ", data[i]);
	}
	printf("\n");
}
