#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int n;
int line;
int p;
int total;
int edge;
char mat[200][3];
int edgeMat[26][26];
int visited[26];
void input();
void display();
void initMat();
void initEdgeMat();
void intVisited();
void solve();
int main()
{
	int k;
	p = 0;
	freopen("p7.txt", "r", stdin);
	scanf("%d", &n);
	getchar();
	getchar();
	for (k = 1; k <= n; k++)
	{
		input();
		solve();
		display();
	}

}
void input()
{
	char ch;
	line = 0;
	initMat();
	while (gets(mat[line]) && mat[line][0] != '\0')
	{
		++line;
	}
}
void display()
{
	printf("%d\n\n", total);
}
void initMat()
{
	int i, j;
	for (i = 0; i < 200; i++)
	{
		for (j = 0; j < 3; j++)
		{
			mat[i][j] = '\0';
		}
	}
}
void solve()
{
	int i;
	int r;
	int c;
	total = mat[0][0] - 65 + 1;
	edge = 0;
	initEdgeMat();
	intVisited();
	for (i = 1; i < line; i++)
	{
		r = mat[i][0] - 65;
		c = mat[i][1] - 65;
		if (edgeMat[r][c] == 0)
		{
			++edge;
			edgeMat[r][c] = 1;
			edgeMat[c][r] = 1;
			//visited[r] = 1;
			//visited[c] = 1;
		}
	}
	total -= edge;
}
void initEdgeMat()
{
	int i, j;
	for (i = 0; i < 26; i++)
	{
		for (j = 0; j < 26; j++)
		{
			edgeMat[i][j] = 0;
		}
	}
}
void intVisited()
{
	int i;
	for (i = 0; i < 26; i++)
	{
		visited[i] = 0;
	}
}