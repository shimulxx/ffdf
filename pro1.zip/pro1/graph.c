#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int t;
int col;
int line;
int isFirst;
int count;
int maxVal;
char mat[25][26];
void read();
void display();
void initMat();
void solve();
void pathFind(int x, int y);
void calcCol();
void display();
int main()
{
	int k;
	isFirst = 1;
	scanf("%d", &t);
	getchar();
	getchar();
	for (k = 1; k <= t; k++)
	{
		read();
		solve();
		if (isFirst == 1)
		{
			display();
			isFirst = 0;
		}
		else
		{
			printf("\n");
			display();
		}
		
	}
}
void read()
{
	line = 0;
	initMat();
	while (gets(mat[line]))
	{
		if (mat[line][0] == '\0')
		{
			break;
		}
		line++;
	}
	calcCol();
}
void display()
{
	printf("%d\n", maxVal);
}
void initMat()
{
	int i, j;
	for (i = 0; i < 25; i++)
	{
		for (j = 0; j < 26; j++)
		{
			mat[i][j] = '\0';
		}
	}
}
void solve()
{
	int i, j;
	count = 0;
	maxVal = 0;
	for (i = 0; i < line; i++)
	{
		for (j = 0; j < col; j++)
		{
			if (mat[i][j] == '1')
			{
				pathFind(i, j);
				if (count > maxVal)
				{
					maxVal = count;
				}
				count = 0;
			}
		}
	}
}
void pathFind(int x, int y)
{
	++count;
	mat[x][y] = '0';
	if (x - 1 >= 0 && y - 1 >= 0 && '1' == mat[x - 1][y - 1])
		pathFind(x - 1, y - 1);
	if (x - 1 >= 0 && '1' == mat[x - 1][y])
		pathFind(x - 1, y);
	if (x - 1 >= 0 && y + 1 < col && '1' == mat[x - 1][y + 1])
		pathFind(x - 1, y + 1);
	if (y - 1 >= 0 && '1' == mat[x][y - 1])
		pathFind(x, y - 1);
	if (y + 1 < col && '1' == mat[x][y + 1])
		pathFind(x, y + 1);
	if (x + 1 < line && y - 1 >= 0 && '1' == mat[x + 1][y - 1])
		pathFind(x + 1, y - 1);
	if (x + 1 < line  && '1' == mat[x + 1][y])
		pathFind(x + 1, y);
	if (x + 1 < line  && y + 1 < col && '1' == mat[x + 1][y + 1])
		pathFind(x + 1, y + 1);
}
void calcCol()
{
	int i;
	for (i = 0; mat[0][i] != '\0'; i++);
	col = i;
}