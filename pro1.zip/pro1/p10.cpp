#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
char mat[200][3];
int row;
int total;
int visited[26];
int admat[26][26];
int ans;
void input();
void display();
void calTotal();
void initAdmat();
void solveWork();
int checkAdja(int i, int j);
void dfs(int i);
int counter();
void setAdmat();
int main()
{
	int k,t;
	freopen("p7.txt", "r", stdin);
	scanf("%d", &t);
	getchar();
	getchar();
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork();
		display();
	}
}
void input()
{
	row = 0;
	while (gets(mat[row]) && mat[row][0] != '\0')
	{
		++row;
	}
}
void display()
{
	printf("%d\n", ans);
}
void calTotal()
{
	total = mat[0][0] - 65 + 1;
}
void initVisit()
{
	int i;
	for (i = 0; i < row; i++)
	{
		visited[i] = 0;
	}
}
void initAdmat()
{
	int i, j;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < row; j++)
		{
			admat[i][j] = 0;
		}
	}
}
int checkAdja(int i, int j)
{
	if (mat[i][j] == 1)
	{
		return 1;
	}
	return 0;
}
void dfs(int i)
{
	int j;
	visited[i] = 1;
	for (j = 0; j < row; j++)
	{
		if (checkAdja(i, j) == 1 && visited[j] == 0)
		{
			dfs(j);
		}
	}
}
int counter()
{
	int i, count = 0;
	for (i = 0; i < row; i++)
	{
		if (visited[i] == 0)
		{
			dfs(i);
			++count;
		}
	}
	return count;
}
void solveWork()
{
	int count;
	calTotal();
	initAdmat();
	setAdmat();
	initVisit();
	count = counter();
	if (count > 0)
		ans = count;
	else
		ans = total;
}
void setAdmat()
{
	int i,r,c;
	for (i = 1; i < row; i++)
	{
		r = mat[i][0] - 65;
		c = mat[i][1] - 65;
		admat[r][c] = 1;
		admat[c][r] = 1;
	}
}