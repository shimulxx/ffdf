#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int a[3];
int visited[3];
int n;
int chess[8][8];
void chessInt();
void display()
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			printf("%d ", chess[i][j]);
		}
		printf("\n");
	}
}
void print()
{
	int i;
	for (i = 0; i < n; i++)
	{
		printf("%d", a[i]);
	}
	printf("\n");
}
void solve(int i)
{
	int j;
	if (i == n)
	{
		print();
		return;
	}
	for (j = 0; j < n; j++)
	{
		if (0 == visited[j])
		{
			a[i] = j;
			visited[j] = 1;
			solve(i + 1);
			visited[j] = 0;
		}
	}
}

int main()
{
	/*int i;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
		visited[i] = 0;
	solve(0);*/
	chessInt();
	display();
	return 0;
}
void chessInt()
{
	int i, j;
	//scanf("%d", &n);
	n = 8;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			chess[i][j] = 0;
		}
	}
}
void queenSet(int i, int j)
{
	int r, c;
	r = i;
	c = j;
	while (r != n)
	{
		chess[r++][c] = 1;
	}
	r = i;
	c = j;
	while (c != n)
	{
		chess[r][c++] = 1;
	}
	r = i;
	c = j;
	while (r != 0)
	{
		chess[r--][c] = 1;
	}
	r = i;
	c = j;
	while (c != 0)
	{
		chess[r][c--] = 1;
	}
	r = i;
	c = j;
	while (c != n || r != n)
	{
		chess[r++][c++] = 1;
	}
	r = i;
	c = j;
	while (c != 0 || c != 0)
	{
		chess[r--][c--] = 1;
	}
	r = i;
	c = j;
	while (c != 0 || c != 0)
	{
		chess[r++][c--] = 1;
	}
	r = i;
	c = j;
	while (c != 0 || c != 0)
	{
		chess[r--][c++] = 1;
	}

}