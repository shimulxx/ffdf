#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#define SIZE 10000
int node;
int edge;
int adMat[SIZE][SIZE];
int color[SIZE];
int colcal[3];
void input();
void display();
void initAdMatColor();
int sum;
int fill(int i, int c);
int solveWork();
int minx(int a, int b);
void initCalcol();
int main()
{
	int k,t;
	freopen("p7.txt", "r", stdin);
	freopen("pop.txt", "w", stdout);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		initAdMatColor();
		input();
		display();
	}
	return 0;
}
void input()
{
	int i, j, k;
	scanf("%d %d",&node,&edge);
	for (k = 1; k <= edge; k++)
	{
		scanf("%d %d", &i, &j);
		adMat[i][j] = 1;
		adMat[j][i] = 1;
	}
}
void initAdMatColor()
{
	int i, j;
	for (i = 0; i < node; i++)
	{
		for (j = 0; j < node; j++)
		{
			adMat[i][j] = 0;
		}
	}
	for (i = 0; i < node; i++)
	{
		color[i] = 0;
	}
}
void display()
{
	if (solveWork() == 0)
	{
		printf("-1\n");
	}
	else
	{
		printf("%d\n", sum);
	}
}
int fill(int i, int c)
{
	int j;
	if (color[i] == 0)
	{
		color[i] = c;
		++colcal[c];
	}
	else if (color[i] == c)
	{
		return 1;
	}
	else
	{
		return 0;
	}
	for (j = 0; j < node; j++)
	{
		if (adMat[i][j] == 1 && 0 == fill(j, 3 - c))
		{
			return 0;
		}
	}
	if ((colcal[1] == 0 && colcal[2] == 1) || (colcal[1] == 1 && colcal[2] == 0))
	{
		sum += 1;
	}
	else
	{
		sum += minx(colcal[1], colcal[2]);
	}
	initCalcol();
	return 1;
}
int solveWork()
{
	int i;
	sum = 0;
	initCalcol();
	for (i = 0; i < node; i++)
	{
		if (color[i] == 0 && 0 == fill(i, 1))
		{
			return 0;
		}
	}
	return 1;
}
int minx(int a, int b)
{
	if (a <= b)
		return a;
	return b;
}
void initCalcol()
{
	int i;
	for (i = 0; i < 3; i++)
	{
		colcal[i] = 0;
	}
}