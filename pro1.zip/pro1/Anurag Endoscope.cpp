#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#define size 1010
int mat[size][size];
int visited[size][size];
int R, C, eR, eC, eS;
int total;
void input();
void solve(int i, int j, int depth);
int up(int i, int j);
int down(int i, int j);
int left(int i, int j);
int right(int i, int j);
void initMat();
void solveWork();
void display();
int main()
{
	int k, t;
	freopen("p7.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		solveWork();
		display();
	}
	return 0;
}
void input()
{
	int i, j;
	scanf("%d %d %d %d %d", &R, &C, &eR, &eC, &eS);
	initMat();
	for (i = 0; i < R; i++)
	{
		for (j = 0; j < C; j++)
		{
			scanf("%d", &mat[i][j]);
			if (mat[i][j] != 0)
			{
				visited[i][j] = 0;
			}
			else
			{
				visited[i][j] = 1;
			}
		}
	}
}
int up(int i, int j)
{
	int x;
	x = mat[i][j];
	if (x == 1 || x == 2 || x == 4 || x == 7)
	{
		return 1;
	}
	return 0;
}
int down(int i, int j)
{
	int x;
	x = mat[i][j];
	if (x == 1 || x == 2 || x == 5 || x == 6)
	{
		return 1;
	}
	return 0;
}
int left(int i, int j)
{
	int x;
	x = mat[i][j];
	if (x == 1 || x == 3 || x == 6 || x == 7)
	{
		return 1;
	}
	return 0;
}
int right(int i, int j)
{
	int x;
	x = mat[i][j];
	if (x == 1 || x == 3 || x == 4 || x == 5)
	{
		return 1;
	}
	return 0;
}
void solve(int i, int j, int depth)
{
	if (depth > eS  || visited[i][j])
	{
		return;
	}
	visited[i][j] = 1;
	++total;
	// up i-1,j
	if (i - 1 >= 0 && up(i, j) && down(i - 1, j))
	{
		solve(i - 1, j, depth + 1);
	}
	// down i+1,j
	if (i + 1 < R && down(i, j) && up(i + 1, j))
	{
		solve(i + 1, j, depth + 1);
	}
	//left i j-1
	if (j - 1 >= 0 && left(i, j) && right(i, j - 1))
	{
		solve(i, j - 1, depth + 1);
	}
	//right i j+1
	if (j + 1 < C && right(i, j) && left(i, j + 1))
	{
		solve(i, j + 1, depth + 1);
	}
}
void solveWork()
{
	total = 0;
	solve(eR, eC, 0);	
}
void initMat()
{
	int i, j;
	for (i = 0; i < R; i++)
	{
		for (j = 0; j < C; j++)
		{
			mat[i][j] = 0;
		}
	}
}
void display()
{
	printf("%d\n", total);
}