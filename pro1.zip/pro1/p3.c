#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int cases;
int t;
int ob[1000][2];
int n, m;
int dp[1001][31];
int solve(int i, int sub, int sum);
void input();
int maxx(int a, int b);
int main()
{
	freopen("p3.txt", "r", stdin);
	scanf("%d", &t);
	for (cases = 1; cases <= t; cases++)
	{
		input();
	}
}
int solve(int i, int sub)
{
	int left, right;
	printf("%d %d\n", i, sub);
	if (dp[i][sub] != -1)
		return dp[i][sub];
	if (i == n)
		return  dp[i][sub] = 0;
	if (ob[i][1] <= sub)
		right = ob[i][0] + solve(i + 1, sub - ob[i][1]);
	else right = 0;
	left = solve(i + 1, sub);
	if (left > right)
		return  dp[i][sub] = left;
	else
		return dp[i][sub] = right;
}

void input()
{
	int i, j, p, total, wr;
	for (i = 0; i < 1001; i++)
	{
		for (j = 0; j < 31; j++)
		{
			dp[i][j] = -1;
		}
	}
	scanf("%d", &n);
	total = 0;
	for (i = 0; i < n; i++)
	{
		scanf("%d %d", &ob[i][0], &ob[i][1]);
	}
	scanf("%d", &p);
	for (i = 1; i <= p; i++)
	{
		scanf("%d", &wr);
		total += solve(0, wr);
	}
	printf("%d\n", total);
}
int maxx(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}

