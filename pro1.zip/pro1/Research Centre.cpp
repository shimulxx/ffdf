#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void input();
#define row 4
#define col 3
int mat[row][col];
int vMat[row][col];
int N, M, R;
int solve(int i, int j, int sum);
int maxx(int a, int b);
int main()
{
	int k, t;
	freopen("p7.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		printf("%d", solve(0, 1, 0));
	}
}
void input()
{
	int i, j, k;
	scanf("%d %d %d", &N, &M, &R);
	for (i = 0; i < N; i++)
	{
		for (j = 0; j < M; j++)
		{
			scanf("%d", &mat[i][j]);
		}
	}
	for (k = 1; k <= R; k++)
	{
		scanf("%d %d", &i, &j);
		mat[i][j] = 100;
	}
}
int solve(int i, int j, int sum)
{
	printf("%d %d\n", i, j);
	int a = 0, b = 0, c = 0, d = 0;
	int x, y;
	if (mat[i][j] == 100)
	{
		return sum;
	}
	vMat[i][j] = 1;
	//i-1 j
	if (i - 1 >= 0 && 1 == mat[i - 1][j] && !vMat[i - 1][j])
	{
	    a = solve(i - 1, j, sum + 1);
		vMat[i - 1][j] = 0;
	}
	//i j-1
	if (j - 1 >= 0 && 1 == mat[i][j - 1] && !vMat[i][j - 1])
	{
		b = solve(i, j - 1, sum + 1);
		vMat[i][j - 1] = 0;
	}
	//i j+1
	if (j + 1 < M && 1 == mat[i][j + 1] && !vMat[i][j + 1])
	{
		c = solve(i, j + 1, sum + 1);
		vMat[i][j + 1] = 0;
	}
	//i+1 j
	if (i + 1 < N && 1 == mat[i + 1][j] && !vMat[i + 1][j])
	{
		d = solve(i + 1, j, sum + 1);
		vMat[i + 1][j] = 0;
	}
	x = maxx(a, b);
	y = maxx(c, d);
	return maxx(x, y);
}
int maxx(int a, int b)
{
	if (a >= b)
		return a;
	return b;
}