#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#define size 10
int admat[size][size];
int n;
void input();
int solve(int i, int j, int sum);
int min2(int a, int b);
int min3(int a, int b, int c);
void initAdMat();
int main()
{
	int k, t;
	freopen("p7.txt", "r", stdin);
	scanf("%d", &t);
	for (k = 1; k <= t; k++)
	{
		input();
		printf("%d\n", solve(n-1, 0, 0));
	}
}
void input()
{
	int i,j;
	scanf("%d", &n);
	initAdMat();
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			scanf("%d", &admat[i][j]);
		}
	}
}
int solve(int i, int j, int sum)
{
	int a, b, c, d;
	int x1, x2, x;
	a = 99999;
	b = 99999;
	c = 99999;
	d = 99999;
	if (admat[i][j] == 3)
	{
		return sum;
	}
	if (admat[i][j] == 0)
	{
		++sum;
	}
	admat[i][j] = 999;
	//i-1 j***
	if (i - 1 >= 0 && admat[i - 1][j] != 999)
	{
		x = admat[i - 1][j];
		a = solve(i - 1, j, sum);
		admat[i - 1][j] = x;
	}
	//i j-1***
	if (j - 1 >= 0 && admat[i][j - 1] != 999)
	{
		x = admat[i][j - 1];
		b = solve(i, j - 1, sum);
		admat[i][j - 1] = x;
	}
	//i j+1****
	if (j + 1 < n && admat[i][j + 1] != 999)
	{
		x = admat[i][j + 1];
		c = solve(i, j + 1, sum);
		admat[i][j + 1] = x;
	}
	//i+1 j****
	if (i + 1 < n && admat[i + 1][j] != 999)
	{
		x = admat[i + 1][j];
		d = solve(i + 1, j, sum);
		admat[i + 1][j] = x;
	}
	x1 = min3(a, b, c);
	x2 = min2(x1, d);
	return x2;
}
int min2(int a, int b)
{
	if (a <= b)
		return a;
	return b;
}
int min3(int a, int b, int c)
{
	int x1, x2;
	x1 = min2(a, b);
	x2 = min2(b, c);
	return min2(x1,x2);
}
void initAdMat()
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			admat[i][j] = 0;
		}
	}
}